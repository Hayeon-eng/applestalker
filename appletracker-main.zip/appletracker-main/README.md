# Apple Tracker (Competitive Intelligence Platform)

This project is fully built based on the APPLE TRACKER MASTER PROMPT.
It tracks Apple and Samsung website changes, utilizes Gemini 2.5 Flash for POV generation, and stores historical records.

## Structure
- `/frontend`: Next.js Web Dashboard
- `/backend`: FastAPI Server, Playwright Crawler, AI Analyzer
- `/snapshots`, `/screenshots`, `/logs`: Storage directories
