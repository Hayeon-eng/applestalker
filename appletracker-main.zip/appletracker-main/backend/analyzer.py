import os
import json
import google.generativeai as genai
from models import POVReport
from database import SessionLocal

SEVEN_CATEGORIES = [
    "SEO·AI 인덱싱", "가격·프로모션", "헤드라인·슬로건",
    "비주얼·미디어", "내비게이션·구조", "CTA·구매 흐름", "본문·기능 설명",
]

CATEGORY_SCHEMA = "\n".join(
    f'    "{c}": {{ "status": "양호"|"주의"|"위험", "summary": "2-3문장 구체 분석", '
    f'"apple_score": 0~10, "samsung_score": 0~10, '
    f'"improvement_points": ["삼성 개선 포인트 1", "포인트 2"] }}'
    for c in SEVEN_CATEGORIES
)


def _save_report(run_id, data):
    db = SessionLocal()
    db.add(POVReport(
        crawl_run_id=run_id,
        change_summary=data.get("change_summary", ""),
        consumer_perception=data.get("consumer_perception", ""),
        samsung_comparison=data.get("samsung_comparison", ""),
        insights_json=json.dumps(data.get("insights", []), ensure_ascii=False),
        action_items_json=json.dumps(data.get("action_items", []), ensure_ascii=False),
        priority_label=data.get("priority_label", "Medium"),
        functional_area=data.get("functional_area", ""),
        category_insights_json=json.dumps(data.get("category_insights", {}), ensure_ascii=False),
    ))
    db.commit()
    db.close()


def generate_pov(run_id: str, changes_summary: str):
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        print("경고: GEMINI_API_KEY 없음 — 기본 리포트 저장")
        _save_report(run_id, {
            "change_summary": "크롤링 완료. GEMINI_API_KEY가 설정되지 않아 AI 분석을 건너뜁니다.",
            "insights": ["Product: GEMINI_API_KEY 환경변수를 설정하면 AI 인사이트가 활성화됩니다."],
            "priority_label": "Low",
            "functional_area": "설정 필요",
        })
        return

    is_snapshot = changes_summary.startswith("COMPETITIVE SNAPSHOT")

    if is_snapshot:
        prompt = f"""당신은 삼성전자 전략팀 소속 선임 경쟁사 인텔리전스 분석가입니다.
아래는 Apple과 Samsung 웹사이트에서 실제 크롤링한 현재 페이지 데이터입니다.
이전 대비 변경은 없으나, 현재 상태를 기반으로 Apple vs Samsung의 경쟁 현황을 심층 분석하세요.

분석 지침:
- 실제 크롤링 데이터(헤드라인, Meta, 가격, CTA, 스키마 등)를 반드시 인용하여 구체적으로 분석
- 단순 "Apple이 좋다" 수준이 아닌, 실제 문구/수치/구조 차이를 명시
- 삼성이 즉시 개선 가능한 포인트를 데이터 기반으로 도출
- 7개 영역 각각에서 Apple 10점 만점 점수, Samsung 점수, 격차 이유 명시
- 데이터·콘텐츠·SEO·UX·가격전략·브랜딩 등 다각도 분석

크롤링 데이터:
{changes_summary}

다음 JSON 구조로만 응답 (마크다운 없이 순수 JSON):
{{
  "change_summary": "전체 경쟁 현황 3-4문장 (실제 데이터 인용 포함)",
  "consumer_perception": "소비자가 각 사이트에서 받는 인상 비교 — 실제 헤드라인/슬로건 인용",
  "samsung_comparison": "삼성 현재 경쟁력의 솔직한 평가 — 점수 격차 큰 영역 중심으로 3-4문장",
  "insights": [
    "AI: (실제 스키마/메타 데이터 인용) 구체 인사이트",
    "UX: (실제 CTA/구조 데이터 인용) 구체 인사이트",
    "Brand: (실제 헤드라인 문구 인용) 구체 인사이트",
    "Product: (실제 제품 설명 데이터 인용) 구체 인사이트",
    "Pricing: (실제 가격 데이터 인용) 구체 인사이트",
    "SEO: (실제 meta description/OG 데이터 인용) 구체 인사이트"
  ],
  "action_items": [
    "🚨 [즉시 - 개발 N일] 구체적 개선 액션 (Apple 사례 인용)",
    "⚠️ [1주 내] 구체적 개선 액션",
    "⚠️ [1주 내] 구체적 개선 액션",
    "👀 [2주 내] 구체적 개선 액션",
    "👀 [2주 내] 구체적 개선 액션"
  ],
  "priority_label": "Critical|High|Medium|Low",
  "functional_area": "핵심 격차 영역 나열",
  "category_insights": {{
{CATEGORY_SCHEMA}
  }}
}}

status 기준: '양호'=삼성 점수 7점 이상, '주의'=4~6점, '위험'=3점 이하
apple_score/samsung_score: 해당 영역 웹사이트 완성도 0~10점"""

    else:
        prompt = f"""당신은 삼성전자 전략팀 소속 선임 경쟁사 인텔리전스 분석가입니다.
경쟁사 웹사이트에서 아래 변경점이 감지되었습니다. 전략적 관점에서 심층 분석해주세요.

분석 지침:
- 감지된 변경 내용을 구체적으로 인용하여 전략적 의도 해석
- 삼성에 미치는 영향과 즉시 대응 방안 도출
- 7개 영역 각각의 현재 상태도 함께 평가 (변경된 영역 중심)

변경 데이터:
{changes_summary}

다음 JSON 구조로만 응답 (마크다운 없이 순수 JSON):
{{
  "change_summary": "변경점 요약 3-4문장 (실제 변경 내용 인용)",
  "consumer_perception": "이 변화가 소비자 인식에 미치는 영향 (삼성 대비)",
  "samsung_comparison": "해당 영역 삼성 경쟁력 평가 및 대응 필요성 3문장",
  "insights": [
    "AI: 구체 인사이트",
    "UX: 구체 인사이트",
    "Brand: 구체 인사이트",
    "Product: 구체 인사이트",
    "Pricing: 구체 인사이트"
  ],
  "action_items": [
    "🚨 [즉시] 구체적 액션",
    "⚠️ [1주 내] 구체적 액션",
    "👀 [2주 내] 구체적 액션"
  ],
  "priority_label": "Critical|High|Medium|Low",
  "functional_area": "주요 영향 영역",
  "category_insights": {{
{CATEGORY_SCHEMA}
  }}
}}"""

    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-2.5-flash")
        response = model.generate_content(prompt)
        raw = response.text.strip()
        if raw.startswith("```"):
            parts = raw.split("```")
            raw = parts[1][4:] if parts[1].startswith("json") else parts[1]
        result = json.loads(raw.strip())
        _save_report(run_id, result)
        print(f"POV 리포트 저장 완료: {run_id}")
    except Exception as e:
        print(f"POV 생성 오류: {e}")
        _save_report(run_id, {
            "change_summary": "크롤링 완료. AI 분석 중 오류가 발생했습니다.",
            "insights": ["Product: AI 분석 오류 — 다음 크롤링 시 자동 재시도됩니다."],
            "priority_label": "Low",
            "functional_area": "분석 오류",
        })
