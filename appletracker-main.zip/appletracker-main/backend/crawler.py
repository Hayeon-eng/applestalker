import asyncio
import uuid
import os
import subprocess
from playwright.async_api import async_playwright
from database import SessionLocal
from models import HistoricalRecord

def _ensure_chromium():
    path = os.path.expanduser(
        "~/.cache/ms-playwright/chromium_headless_shell-1223"
        "/chrome-headless-shell-linux64/chrome-headless-shell"
    )
    if not os.path.exists(path):
        print("Chromium 설치 중...")
        subprocess.run(["playwright", "install", "chromium"], check=True)


TIERS = {
    "Tier 0": [
        "https://www.apple.com/",
        "https://www.samsung.com/sg/",
    ],
    "Tier 1": [
        "https://www.apple.com/iphone/",
        "https://www.apple.com/watch/",
        "https://www.apple.com/airpods/",
        "https://www.samsung.com/sg/smartphones/all-smartphones/",
        "https://www.samsung.com/sg/watches/all-watches/",
        "https://www.samsung.com/sg/audio-sound/all-audio-sound/",
    ],
    "Tier 2": [
        "https://www.apple.com/apple-intelligence/",
        "https://www.apple.com/iphone/compare/",
        "https://www.apple.com/watch/compare/",
        "https://www.samsung.com/sg/mobile/",
        "https://www.samsung.com/sg/galaxy-ai/",
        "https://www.samsung.com/sg/mobile/find-your-galaxy/",
        "https://www.samsung.com/sg/mobile/switch-to-galaxy/",
        "https://www.samsung.com/sg/one-ui/",
    ],
    "Tier 3": [
        "https://www.apple.com/iphone-17-pro/",
        "https://www.apple.com/iphone-air/",
        "https://www.apple.com/iphone-17/",
        "https://www.apple.com/iphone-17e/",
        "https://www.apple.com/apple-watch-series-11/",
        "https://www.apple.com/apple-watch-ultra-3/",
        "https://www.apple.com/apple-watch-se-3/",
        "https://www.apple.com/airpods-pro/",
        "https://www.samsung.com/sg/smartphones/galaxy-s26-ultra/",
        "https://www.samsung.com/sg/smartphones/galaxy-s26/",
        "https://www.samsung.com/sg/smartphones/galaxy-z-fold7/",
        "https://www.samsung.com/sg/smartphones/galaxy-z-flip7/",
        "https://www.samsung.com/sg/watches/galaxy-watch-ultra-2025/",
        "https://www.samsung.com/sg/audio-sound/galaxy-buds4-pro/",
    ],
    "Tier 4": [
        "https://www.apple.com/iphone-17-pro/specs/",
        "https://www.apple.com/iphone-air/specs/",
        "https://www.apple.com/iphone-17/specs/",
        "https://www.apple.com/iphone-17e/specs/",
        "https://www.apple.com/apple-watch-series-11/specs/",
        "https://www.apple.com/apple-watch-ultra-3/specs/",
        "https://www.apple.com/apple-watch-se-3/specs/",
        "https://www.apple.com/airpods-pro/specs/",
        "https://www.apple.com/shop/buy-iphone",
        "https://www.samsung.com/sg/smartphones/galaxy-s26-ultra/buy/",
        "https://www.samsung.com/sg/smartphones/galaxy-s26/buy/",
        "https://www.samsung.com/sg/smartphones/galaxy-z-fold7/buy/",
        "https://www.samsung.com/sg/smartphones/galaxy-z-flip7/buy/",
        "https://www.samsung.com/sg/watches/galaxy-watch-ultra-2025/buy/",
        "https://www.samsung.com/sg/audio-sound/galaxy-buds4-pro/buy/",
    ],
}

PAGE_TIMEOUT = 60_000
PAGE_RETRIES = 1
_crawl_lock       = asyncio.Lock()
_progress_queues: list[asyncio.Queue] = []

# main.py에서 중단 플래그를 주입할 수 있도록 callable 참조
_stop_flag_getter = None

def set_stop_flag_getter(fn):
    global _stop_flag_getter
    _stop_flag_getter = fn

def _should_stop() -> bool:
    if _stop_flag_getter:
        return _stop_flag_getter()
    return False

def subscribe_progress() -> asyncio.Queue:
    q: asyncio.Queue = asyncio.Queue()
    _progress_queues.append(q)
    return q

def unsubscribe_progress(q: asyncio.Queue):
    try: _progress_queues.remove(q)
    except ValueError: pass

def _broadcast(event: dict):
    for q in list(_progress_queues):
        try: q.put_nowait(event)
        except asyncio.QueueFull: pass


async def _collect_page(page, url: str, site: str, run_id: str, tier: str):
    last_error = None
    for attempt in range(PAGE_RETRIES + 1):
        try:
            if attempt > 0:
                print(f"  ↺ 재시도 ({attempt}/{PAGE_RETRIES}): {url}")
                await asyncio.sleep(3)
            await page.goto(url, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT)
            title   = await page.title()
            content = await page.content()
            db = SessionLocal()
            db.add(HistoricalRecord(
                site_name=site, crawl_run_id=run_id,
                url=url, tier=tier, title=title,
                body_content=content[:5000],
            ))
            db.commit()
            db.close()
            print(f"  ✓ {url}")
            _broadcast({"type": "page_done", "status": "success",
                        "url": url, "site": site, "tier": tier, "title": title})
            return
        except Exception as e:
            last_error = e
            print(f"  ✗ 시도 {attempt+1} {url} — {e}")

    _broadcast({"type": "page_done", "status": "error",
                "url": url, "site": site, "tier": tier,
                "error": f"Timeout ({PAGE_TIMEOUT//1000}s) — 재시도 {PAGE_RETRIES}회 후 실패"})
    raise last_error


async def run_crawler(tiers: list[str] | None = None) -> str:
    """
    tiers: 크롤링할 Tier 목록. None이면 전체.
    """
    async with _crawl_lock:
        _ensure_chromium()
        run_id = str(uuid.uuid4())

        target_tiers = {k: v for k, v in TIERS.items() if tiers is None or k in tiers}
        total_urls   = sum(len(v) for v in target_tiers.values())
        print(f"=== 크롤링 시작: {run_id} ({list(target_tiers.keys())}) ===")
        _broadcast({"type": "start", "run_id": run_id, "total": total_urls,
                    "tiers": list(target_tiers.keys())})

        async with async_playwright() as p:
            for tier, urls in target_tiers.items():
                if _should_stop():
                    print("  ⏹ 중단 요청으로 크롤링 중지")
                    _broadcast({"type": "stopped", "run_id": run_id})
                    return run_id

                print(f"[{tier}]")
                _broadcast({"type": "tier_start", "tier": tier, "count": len(urls)})

                browser = await p.chromium.launch(
                    headless=True,
                    args=["--no-sandbox", "--disable-dev-shm-usage",
                          "--disable-gpu", "--single-process"],
                )
                page = await browser.new_page()
                await page.set_extra_http_headers({"Accept-Language": "en-US,en;q=0.9"})

                for url in urls:
                    if _should_stop():
                        await browser.close()
                        _broadcast({"type": "stopped", "run_id": run_id})
                        return run_id

                    site = "Apple" if "apple.com" in url else "Samsung"
                    try:
                        await _collect_page(page, url, site, run_id, tier)
                        await asyncio.sleep(1)
                    except Exception:
                        pass

                await browser.close()

        print(f"=== 크롤링 완료: {run_id} ===")
        _broadcast({"type": "done", "run_id": run_id})
        return run_id
