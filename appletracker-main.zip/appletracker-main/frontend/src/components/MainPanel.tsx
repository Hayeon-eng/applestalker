import { useState, useEffect, useRef } from 'react';
import { ReportData, DataChange, DiffDetail, Analysis, CategoryInsight } from '../app/page';

interface Props { report: ReportData; onRefresh: () => void; isDemo?: boolean; isSnapshot?: boolean; }

const C = {
  surface: '#FFFFFF', border: '#E8EAED',
  text: '#111318', textSub: '#6B7280', textMute: '#9CA3AF',
  blue: '#2563EB', blueBg: '#EFF6FF', blueBorder: '#BFDBFE',
};

const SEV: Record<string, { bg: string; color: string; border: string; dot: string; label: string; tag: string }> = {
  Critical: { bg: '#FEF2F2', color: '#991B1B', border: '#FECACA', dot: '#EF4444', label: '즉시 확인',     tag: '🚨' },
  High:     { bg: '#FFF7ED', color: '#92400E', border: '#FED7AA', dot: '#F97316', label: '모니터링 권장', tag: '⚠️' },
  Medium:   { bg: '#FEFCE8', color: '#713F12', border: '#FEF08A', dot: '#EAB308', label: '내용 확인',     tag: '👀' },
  Low:      { bg: '#F0FDF4', color: '#14532D', border: '#BBF7D0', dot: '#22C55E', label: '참고용',        tag: '📌' },
};

const SEV_DESC: Record<string, { what: string; examples: string; action: string }> = {
  Critical: { what: '전략 핵심 영역 대규모 변경',      examples: '예) 메타 타이틀·스키마 구조 변경, 가격 개편, 신제품 런칭 페이지 오픈, 전체 내비게이션 개편', action: '즉시 대응 — 경쟁사 전략 변화 파악 및 액션 필요' },
  High:     { what: '주요 메시지·비주얼 교체',         examples: '예) Hero 헤드라인 슬로건 교체, 메인 이미지 전환, 캠페인 페이지 신규 오픈, CTA 버튼 문구 변경', action: '검토 필요 - 내용 확인 후 벤치마킹 권장' },
  Medium:   { what: '제품 설명·기능 본문 업데이트',    examples: '예) 스펙 문구 수정, 기능 설명 단락 추가·삭제, 이미지 ALT 텍스트 변경, 서브 페이지 내용 보완', action: '참고 필요 - 경쟁사 동향 파악용' },
  Low:      { what: '미세 수정 (오탈자·여백·링크 등)', examples: '예) 오탈자 교정, 문장 부호 수정, 링크 URL 변경, 법적 고지 문구 업데이트',                action: '검토 불필요 — 정기 모니터링용' },
};

const TYPE_DISPLAY: Record<string, string> = {
  'SEO·AI 인덱싱': '검색·AI 노출', '가격·프로모션': '가격·혜택', '헤드라인·슬로건': '헤드라인',
  '비주얼·미디어': '이미지·영상',  '내비게이션·구조': '사이트 구조', 'CTA·구매 흐름': '구매 유도', '본문·기능 설명': '제품 설명',
};
const TYPE_EMOJI: Record<string, string> = {
  'SEO·AI 인덱싱': '🔎', '가격·프로모션': '💰', '헤드라인·슬로건': '✏️',
  '비주얼·미디어': '🖼', '내비게이션·구조': '🗂', 'CTA·구매 흐름': '🛒', '본문·기능 설명': '📄',
};
const TYPE_STYLE: Record<string, { bg: string; color: string; border: string }> = {
  'SEO·AI 인덱싱':  { bg: '#EFF6FF', color: '#1D4ED8', border: '#BFDBFE' },
  '가격·프로모션':   { bg: '#F0FDF4', color: '#15803D', border: '#BBF7D0' },
  '헤드라인·슬로건': { bg: '#FAF5FF', color: '#7E22CE', border: '#E9D5FF' },
  '비주얼·미디어':   { bg: '#FFF7ED', color: '#C2410C', border: '#FED7AA' },
  '내비게이션·구조': { bg: '#F9FAFB', color: '#374151', border: '#E5E7EB' },
  'CTA·구매 흐름':  { bg: '#FFF1F2', color: '#BE123C', border: '#FECDD3' },
  '본문·기능 설명':  { bg: '#F9FAFB', color: '#4B5563', border: '#E5E7EB' },
};

const SITE_CONFIG: Record<string, { emoji: string; accentBg: string; accentBorder: string; accentColor: string; dot: string }> = {
  Apple:   { emoji: '🍎', accentBg: '#F9FAFB', accentBorder: '#E5E7EB', accentColor: '#111318', dot: '#111318' },
  Samsung: { emoji: '🔷', accentBg: '#EFF6FF', accentBorder: '#BFDBFE', accentColor: '#1D4ED8', dot: '#2563EB' },
};

const CARD: React.CSSProperties = { background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12 };

const fmt = (ts: string | null) => { if (!ts) return 'N/A'; const d = new Date(ts); return isNaN(d.getTime()) ? ts : d.toLocaleString('ko-KR'); };

const ALLCAPS = new Set(['ai', 'seo', 'ui', 'ux', 'api', 'tv', 'vr', 'ar', 'nfc', 'usb', 'sdk']);
const pageName = (url: string) => {
  try {
    const u = new URL(url); const parts = u.pathname.replace(/\/$/, '').split('/').filter(Boolean);
    const host = u.hostname.replace('www.', '');
    if (parts.length === 0) return host.includes('apple') ? 'Apple 홈' : 'Samsung 홈';
    const last = parts[parts.length - 1];
    return last.split('-').map(w => ALLCAPS.has(w.toLowerCase()) ? w.toUpperCase() : w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  } catch { return url; }
};
const siteDomain = (url: string) => { try { return new URL(url).hostname.replace('www.', ''); } catch { return url; } };
const volumeText = (a: number, r: number) => { const t = a+r; if (t>=100) return '대규모 업데이트'; if (t>=30) return '상당한 변경'; if (t>=10) return '일부 변경'; return '소폭 수정'; };

// ── 팝업 SeverityBadge ────────────────────────────────────────────────────────
function SeverityBadge({ label }: { label: string }) {
  const s = SEV[label] || SEV.Low;
  const d = SEV_DESC[label] || SEV_DESC.Low;
  const ref = useRef<HTMLSpanElement>(null);
  const [open, setOpen] = useState(false);
  const [rect, setRect] = useState<DOMRect | null>(null);
  const show = () => { if (ref.current) { setRect(ref.current.getBoundingClientRect()); setOpen(true); } };
  const hide = () => setOpen(false);
  useEffect(() => {
    if (!open) return;
    const close = () => setOpen(false);
    window.addEventListener('scroll', close, true); window.addEventListener('resize', close);
    return () => { window.removeEventListener('scroll', close, true); window.removeEventListener('resize', close); };
  }, [open]);
  return (
    <>
      <span ref={ref} onMouseEnter={show} onMouseLeave={hide}
        style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '3px 9px', borderRadius: 20, fontSize: 11, fontWeight: 700, background: s.bg, color: s.color, border: `1px solid ${s.border}`, cursor: 'help', userSelect: 'none' }}>
        <span style={{ fontSize: 12 }}>{s.tag}</span>{s.label}
      </span>
      {open && rect && (
        <div onMouseEnter={show} onMouseLeave={hide} style={{ position: 'fixed', zIndex: 99999, pointerEvents: 'auto', top: rect.top - 8, left: rect.left + rect.width / 2, transform: 'translate(-50%, -100%)', background: '#1C1C1E', color: '#fff', borderRadius: 12, padding: '14px 16px', width: 280, boxShadow: '0 8px 32px rgba(0,0,0,0.28)', border: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10, paddingBottom: 10, borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
            <span style={{ fontSize: 18 }}>{s.tag}</span>
            <span style={{ fontSize: 13, fontWeight: 700 }}>{s.label}</span>
            <span style={{ marginLeft: 'auto', fontSize: 10, padding: '2px 8px', borderRadius: 20, background: `${s.dot}30`, color: s.dot, fontWeight: 600 }}>{label}</span>
          </div>
          <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.92)', margin: '0 0 5px', fontWeight: 600 }}>{d.what}</p>
          <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.55)', margin: '0 0 10px', lineHeight: 1.65 }}>{d.examples}</p>
          <div style={{ background: `${s.dot}18`, borderRadius: 8, padding: '7px 10px', border: `1px solid ${s.dot}30` }}>
            <p style={{ fontSize: 11, color: s.dot, margin: 0, fontWeight: 600 }}>→ {d.action}</p>
          </div>
          <div style={{ position: 'absolute', top: '100%', left: '50%', transform: 'translateX(-50%)', width: 0, height: 0, borderLeft: '7px solid transparent', borderRight: '7px solid transparent', borderTop: '7px solid #1C1C1E' }} />
        </div>
      )}
    </>
  );
}

// ── DiffDetailPanel ───────────────────────────────────────────────────────────
function DiffDetailPanel({ detail }: { detail: DiffDetail }) {
  const hasCopies  = detail.copies  && detail.copies.length  > 0;
  const hasImages  = detail.images  && detail.images.length  > 0;
  const hasSchemas = detail.schemas && detail.schemas.length > 0;
  if (!hasCopies && !hasImages && !hasSchemas) return null;
  return (
    <div style={{ borderTop: `1px solid ${C.border}`, padding: '12px 14px', background: '#F9FAFB', display: 'flex', flexDirection: 'column', gap: 14 }}>
      {hasCopies && (
        <div>
          <p style={{ fontSize: 10, fontWeight: 700, color: C.textSub, margin: '0 0 8px', textTransform: 'uppercase', letterSpacing: '0.07em' }}>✏️ 카피 변경</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {detail.copies!.map((cp, i) => (
              <div key={i} style={{ borderRadius: 8, overflow: 'hidden', border: `1px solid ${C.border}` }}>
                <div style={{ padding: '5px 10px', background: '#F3F4F6', borderBottom: `1px solid ${C.border}` }}>
                  <span style={{ fontSize: 10, fontWeight: 700, color: C.textSub }}>{cp.location}</span>
                </div>
                <div style={{ padding: '7px 10px', background: '#FEF2F2', borderBottom: `1px solid #FECACA` }}>
                  <span style={{ fontSize: 9, color: '#EF4444', fontWeight: 700, display: 'block', marginBottom: 3 }}>이전</span>
                  <p style={{ fontSize: 11, color: '#7F1D1D', margin: 0, lineHeight: 1.6, fontStyle: 'italic' }}>"{cp.old}"</p>
                </div>
                <div style={{ padding: '7px 10px', background: '#F0FDF4' }}>
                  <span style={{ fontSize: 9, color: '#22C55E', fontWeight: 700, display: 'block', marginBottom: 3 }}>이후</span>
                  <p style={{ fontSize: 11, color: '#14532D', margin: 0, lineHeight: 1.6, fontStyle: 'italic' }}>"{cp.new}"</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      {hasImages && (
        <div>
          <p style={{ fontSize: 10, fontWeight: 700, color: C.textSub, margin: '0 0 8px', textTransform: 'uppercase', letterSpacing: '0.07em' }}>🖼 이미지 변경</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {detail.images!.map((img, i) => {
              const sc = img.status === '추가' ? { bg: '#F0FDF4', border: '#BBF7D0', color: '#14532D' }
                       : img.status === '교체' ? { bg: '#FFF7ED', border: '#FED7AA', color: '#92400E' }
                       : { bg: '#FEF2F2', border: '#FECACA', color: '#991B1B' };
              return (
                <div key={i} style={{ borderRadius: 8, border: `1px solid ${sc.border}`, overflow: 'hidden' }}>
                  <div style={{ padding: '5px 10px', background: sc.bg, borderBottom: `1px solid ${sc.border}`, display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ fontSize: 10, fontWeight: 700, color: sc.color, background: '#fff', padding: '1px 7px', borderRadius: 4, border: `1px solid ${sc.border}` }}>{img.status}</span>
                    <span style={{ fontSize: 10, fontWeight: 600, color: sc.color }}>{img.location}</span>
                  </div>
                  <div style={{ padding: '8px 10px', background: '#fff' }}>
                    {img.old && <div style={{ marginBottom: img.new ? 6 : 0 }}><span style={{ fontSize: 9, color: '#EF4444', fontWeight: 700, display: 'block', marginBottom: 2 }}>이전</span><p style={{ fontSize: 11, color: C.textSub, margin: 0, lineHeight: 1.6 }}>{img.old}</p></div>}
                    {img.new && <div><span style={{ fontSize: 9, color: '#22C55E', fontWeight: 700, display: 'block', marginBottom: 2 }}>이후</span><p style={{ fontSize: 11, color: C.text, margin: 0, lineHeight: 1.6 }}>{img.new}</p></div>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
      {hasSchemas && (
        <div>
          <p style={{ fontSize: 10, fontWeight: 700, color: C.textSub, margin: '0 0 8px', textTransform: 'uppercase', letterSpacing: '0.07em' }}>{'</>'} 스키마 변경</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {detail.schemas!.map((sc, i) => {
              const ss = sc.status === '추가' ? { bg: '#F0FDF4', border: '#BBF7D0', color: '#14532D' }
                       : sc.status === '수정' ? { bg: '#FFF7ED', border: '#FED7AA', color: '#92400E' }
                       : { bg: '#FEF2F2', border: '#FECACA', color: '#991B1B' };
              return (
                <div key={i} style={{ borderRadius: 8, overflow: 'hidden', border: `1px solid ${C.border}` }}>
                  <div style={{ padding: '6px 10px', background: '#F3F4F6', borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', gap: 7 }}>
                    <span style={{ fontSize: 10, fontWeight: 700, color: ss.color, background: ss.bg, padding: '1px 8px', borderRadius: 4, border: `1px solid ${ss.border}` }}>{sc.status}</span>
                    <span style={{ fontSize: 11, fontWeight: 600, color: C.text, fontFamily: 'monospace' }}>{sc.type}</span>
                  </div>
                  {sc.old && <div style={{ borderBottom: `1px solid ${C.border}` }}><div style={{ padding: '4px 10px', background: '#FEF2F2', borderBottom: `1px solid #FECACA` }}><span style={{ fontSize: 9, color: '#EF4444', fontWeight: 700 }}>이전</span></div><pre style={{ margin: 0, padding: '8px 12px', background: '#FFF5F5', fontSize: 10, lineHeight: 1.7, color: '#7F1D1D', fontFamily: 'monospace', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{sc.old}</pre></div>}
                  {sc.new && <div><div style={{ padding: '4px 10px', background: '#F0FDF4', borderBottom: `1px solid #BBF7D0` }}><span style={{ fontSize: 9, color: '#22C55E', fontWeight: 700 }}>이후</span></div><pre style={{ margin: 0, padding: '8px 12px', background: '#F9FFF9', fontSize: 10, lineHeight: 1.7, color: '#14532D', fontFamily: 'monospace', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{sc.new}</pre></div>}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ── ChangeCard ────────────────────────────────────────────────────────────────
function ChangeCard({ c }: { c: DataChange }) {
  const s         = SEV[c.severity] || SEV.Low;
  const isSamsung = c.site === 'Samsung';
  const hasDetail = c.diff_detail && (
    (c.diff_detail.copies  && c.diff_detail.copies.length  > 0) ||
    (c.diff_detail.images  && c.diff_detail.images.length  > 0) ||
    (c.diff_detail.schemas && c.diff_detail.schemas.length > 0)
  );
  const [expanded, setExpanded] = useState(false);
  return (
    <div style={{ borderRadius: 10, border: `1px solid ${C.border}`, borderLeft: `3px solid ${s.dot}`, background: C.surface, overflow: 'visible' }}>
      <div onClick={() => hasDetail && setExpanded(v => !v)} style={{ padding: '9px 12px 8px', borderBottom: expanded ? `1px solid ${C.border}` : 'none', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8, background: s.bg, borderRadius: expanded ? '8px 8px 0 0' : 8, cursor: hasDetail ? 'pointer' : 'default' }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: 12, fontWeight: 600, color: C.text, margin: 0 }}>{pageName(c.url)}</p>
          <p style={{ fontSize: 10, color: C.textMute, margin: '2px 0 0' }}>{siteDomain(c.url)} · {c.tier}</p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
          {!isSamsung && <SeverityBadge label={c.severity} />}
          {hasDetail && <span style={{ fontSize: 10, color: C.textMute, background: '#F3F4F6', border: `1px solid ${C.border}`, borderRadius: 6, padding: '2px 7px', userSelect: 'none' }}>{expanded ? '▲ 닫기' : '▼ 상세'}</span>}
        </div>
      </div>
      <div style={{ padding: '8px 12px 10px', background: C.surface, borderRadius: expanded ? 0 : '0 0 8px 8px' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 6 }}>
          {(c.change_types || []).map(key => {
            const st = TYPE_STYLE[key] || { bg: '#F9FAFB', color: '#4B5563', border: '#E5E7EB' };
            return <span key={key} style={{ fontSize: 10, padding: '2px 8px', borderRadius: 6, fontWeight: 600, background: st.bg, color: st.color, border: `1px solid ${st.border}`, display: 'flex', alignItems: 'center', gap: 3 }}>{TYPE_EMOJI[key] || ''} {TYPE_DISPLAY[key] || key}</span>;
          })}
        </div>
        <p style={{ fontSize: 10, color: C.textMute, margin: 0 }}>{volumeText(c.added, c.removed)}{c.title_changed ? ' · 페이지 제목 변경' : ''}</p>
      </div>
      {expanded && c.diff_detail && <DiffDetailPanel detail={c.diff_detail} />}
    </div>
  );
}

// ── SEVEN_CATS 영역 정의 ──────────────────────────────────────────────────────
const SEVEN_CATS = [
  { key: 'SEO·AI 인덱싱',  emoji: '🔎', label: 'SEO·AI 인덱싱' },
  { key: '헤드라인·슬로건', emoji: '✏️', label: '헤드라인·슬로건' },
  { key: '가격·프로모션',   emoji: '💰', label: '가격·프로모션' },
  { key: '비주얼·미디어',   emoji: '🖼',  label: '비주얼·미디어' },
  { key: 'CTA·구매 흐름',  emoji: '🛒', label: 'CTA·구매 흐름' },
  { key: '내비게이션·구조', emoji: '🗂',  label: '내비게이션·구조' },
  { key: '본문·기능 설명',  emoji: '📄', label: '본문·기능 설명' },
];

const STATUS_STYLE: Record<string, { bg: string; color: string; dot: string; border: string; label: string }> = {
  '양호': { bg: '#F0FDF4', color: '#14532D', dot: '#22C55E', border: '#BBF7D0', label: '양호' },
  '주의': { bg: '#FFF7ED', color: '#92400E', dot: '#F97316', border: '#FED7AA', label: '주의' },
  '위험': { bg: '#FEF2F2', color: '#991B1B', dot: '#EF4444', border: '#FECACA', label: '위험' },
};

const categoryConfig: Record<string, { bg: string; color: string; label: string; emoji: string }> = {
  AI:      { bg: 'rgba(37,99,235,0.08)',  color: '#1A4FA8', label: 'AI',      emoji: '🤖' },
  UX:      { bg: 'rgba(52,199,89,0.08)',  color: '#1A6B3A', label: 'UX',      emoji: '✨' },
  Brand:   { bg: 'rgba(175,82,222,0.08)', color: '#5B2DA0', label: 'Brand',   emoji: '💎' },
  Product: { bg: 'rgba(255,149,0,0.08)',  color: '#8A4500', label: 'Product', emoji: '📦' },
  Pricing: { bg: 'rgba(255,59,48,0.08)',  color: '#A0001A', label: 'Pricing', emoji: '💰' },
  General: { bg: 'rgba(0,0,0,0.04)',      color: '#555555', label: '일반',    emoji: '📌' },
};

function parseInsight(raw: string) {
  const sep = raw.indexOf(': ');
  if (sep > 0 && sep < 12) return { category: raw.slice(0, sep), text: raw.slice(sep + 2) };
  return { category: 'General', text: raw };
}

// ── Snapshot 전용 풀스크린 대시보드 ──────────────────────────────────────────
function SnapshotDashboard({ report, onRefresh, isDemo }: { report: ReportData; onRefresh: () => void; isDemo?: boolean }) {
  const { analysis, total_changed_urls } = report;
  if (!analysis) return null;

  const statusOrder: Record<string, number> = { '위험': 0, '주의': 1, '양호': 2 };
  const sortedCats = [...SEVEN_CATS].sort((a, b) => {
    const sa = statusOrder[analysis.category_insights?.[a.key]?.status ?? '양호'] ?? 2;
    const sb = statusOrder[analysis.category_insights?.[b.key]?.status ?? '양호'] ?? 2;
    return sa - sb;
  });

  const riskCount   = SEVEN_CATS.filter(c => analysis.category_insights?.[c.key]?.status === '위험').length;
  const cautionCount = SEVEN_CATS.filter(c => analysis.category_insights?.[c.key]?.status === '주의').length;
  const goodCount   = SEVEN_CATS.filter(c => analysis.category_insights?.[c.key]?.status === '양호').length;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

      {/* 헤더 */}
      <div style={{ ...CARD, padding: '16px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <h1 style={{ fontSize: 16, fontWeight: 700, margin: '0 0 6px', color: C.text, letterSpacing: '-0.5px' }}>경쟁사 현황 분석 대시보드</h1>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, alignItems: 'center' }}>
              <a href={report.url} target="_blank" rel="noopener noreferrer" style={{ fontSize: 11, color: C.blue, textDecoration: 'none' }}>{report.url}</a>
              <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 20, background: '#F3F4F6', color: C.textSub, border: `1px solid ${C.border}` }}>{report.tier}</span>
              {analysis.priority_label && <SeverityBadge label={analysis.priority_label} />}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexShrink: 0 }}>
            <span style={{ fontSize: 10, color: C.textMute }}>{fmt(report.timestamp)}</span>
            {!isDemo && <button onClick={onRefresh} style={{ padding: '5px 12px', borderRadius: 8, border: `1px solid ${C.border}`, background: C.surface, cursor: 'pointer', fontSize: 11, color: C.text, fontWeight: 500 }}>새로고침</button>}
          </div>
        </div>
        <div style={{ marginTop: 12, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: '#FAF5FF', borderRadius: 8, padding: '5px 12px', border: '1px solid #E9D5FF' }}>
            <span style={{ fontSize: 12 }}>📸</span>
            <span style={{ fontSize: 11, color: '#7E22CE', fontWeight: 600 }}>변경 없음 — 현재 상태 기반 분석</span>
          </div>
          {isDemo && (
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: '#FFF7ED', borderRadius: 8, padding: '5px 12px', border: '1px solid #FED7AA' }}>
              <span style={{ fontSize: 12 }}>✦</span>
              <span style={{ fontSize: 11, color: '#92400E', fontWeight: 600 }}>예시 데이터</span>
            </div>
          )}
        </div>
      </div>

      {/* 요약 3컬럼 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14 }}>
        <div style={{ ...CARD, padding: '16px 18px', borderTop: `3px solid ${C.text}` }}>
          <p style={{ fontSize: 10, fontWeight: 700, color: C.textSub, margin: '0 0 8px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>🗒 현재 상태 요약</p>
          <p style={{ fontSize: 12, color: C.text, lineHeight: 1.8, margin: 0 }}>{analysis.change_summary}</p>
        </div>
        <div style={{ ...CARD, padding: '16px 18px', borderTop: `3px solid ${C.blue}` }}>
          <p style={{ fontSize: 10, fontWeight: 700, color: '#1D4ED8', margin: '0 0 8px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>👁 Apple 현재 전략</p>
          <p style={{ fontSize: 12, color: C.text, lineHeight: 1.8, margin: 0 }}>{analysis.consumer_perception}</p>
        </div>
        <div style={{ ...CARD, padding: '16px 18px', borderTop: `3px solid #F97316` }}>
          <p style={{ fontSize: 10, fontWeight: 700, color: '#92400E', margin: '0 0 8px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>⚡ Samsung vs Apple 격차</p>
          <p style={{ fontSize: 12, color: C.text, lineHeight: 1.8, margin: 0 }}>{analysis.samsung_comparison}</p>
        </div>
      </div>

      {/* 영역별 현황 + 인사이트 2컬럼 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 0.9fr', gap: 14, alignItems: 'start' }}>

        {/* 7개 영역별 현황 */}
        <div style={{ ...CARD, overflow: 'hidden' }}>
          <div style={{ padding: '12px 16px', borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 14 }}>📊</span>
            <p style={{ fontSize: 13, fontWeight: 700, margin: 0, color: C.text, flex: 1 }}>7개 영역별 Apple vs Samsung 현황</p>
            <div style={{ display: 'flex', gap: 6 }}>
              {riskCount > 0 && <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 20, background: '#FEF2F2', color: '#991B1B', border: '1px solid #FECACA' }}>위험 {riskCount}</span>}
              {cautionCount > 0 && <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 20, background: '#FFF7ED', color: '#92400E', border: '1px solid #FED7AA' }}>주의 {cautionCount}</span>}
              {goodCount > 0 && <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 20, background: '#F0FDF4', color: '#14532D', border: '1px solid #BBF7D0' }}>양호 {goodCount}</span>}
            </div>
          </div>
          <div style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 8 }}>
            {sortedCats.map(({ key, emoji, label }) => {
              const insight = analysis.category_insights?.[key];
              if (!insight) return null;
              const st = STATUS_STYLE[insight.status] || STATUS_STYLE['양호'];
              return (
                <div key={key} style={{ borderRadius: 10, border: `1px solid ${st.border}`, background: st.bg, overflow: 'hidden' }}>
                  <div style={{ padding: '9px 12px', display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 14 }}>{emoji}</span>
                    <p style={{ fontSize: 12, fontWeight: 600, margin: 0, color: C.text, flex: 1 }}>{label}</p>
                    <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 9px', borderRadius: 20, background: `${st.dot}18`, color: st.color, border: `1px solid ${st.border}`, display: 'flex', alignItems: 'center', gap: 4 }}>
                      <span style={{ width: 5, height: 5, borderRadius: '50%', background: st.dot, display: 'inline-block' }} />
                      {st.label}
                    </span>
                  </div>
                  <div style={{ padding: '0 12px 10px 38px' }}>
                    <p style={{ fontSize: 11, color: C.textSub, margin: 0, lineHeight: 1.7 }}>{insight.summary}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 우측: 핵심 인사이트 + 즉시 액션 */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

          {/* 핵심 인사이트 */}
          <div style={{ ...CARD, overflow: 'hidden' }}>
            <div style={{ padding: '12px 16px', borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 14 }}>⚡</span>
              <p style={{ fontSize: 13, fontWeight: 700, margin: 0, color: C.text }}>핵심 인사이트</p>
            </div>
            <div style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 8 }}>
              {(analysis.insights || []).map((raw, i) => {
                const { category, text } = parseInsight(raw);
                const cfg = categoryConfig[category] || categoryConfig.General;
                return (
                  <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start', padding: '9px 11px', borderRadius: 9, background: 'rgba(0,0,0,0.02)', border: '1px solid rgba(0,0,0,0.06)' }}>
                    <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 7px', borderRadius: 5, background: cfg.bg, color: cfg.color, whiteSpace: 'nowrap', flexShrink: 0, marginTop: 1, display: 'flex', alignItems: 'center', gap: 3 }}>
                      <span>{cfg.emoji}</span> {cfg.label}
                    </span>
                    <p style={{ fontSize: 11, lineHeight: 1.65, margin: 0, color: C.text }}>{text}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 즉시 실행 액션 */}
          <div style={{ background: C.blueBg, borderRadius: 12, border: `1px solid ${C.blueBorder}`, overflow: 'hidden' }}>
            <div style={{ padding: '12px 16px', borderBottom: `1px solid ${C.blueBorder}`, display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 14 }}>🎯</span>
              <p style={{ fontSize: 13, fontWeight: 700, margin: 0, color: '#1A3A7A' }}>즉시 실행 액션</p>
            </div>
            <div style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 7 }}>
              {(analysis.action_items || []).map((item, i) => (
                <div key={i} style={{ display: 'flex', gap: 9, alignItems: 'flex-start', padding: '9px 11px', borderRadius: 9, background: 'rgba(255,255,255,0.7)', border: `1px solid ${C.blueBorder}` }}>
                  <span style={{ fontSize: 11, color: C.blue, fontWeight: 700, flexShrink: 0, minWidth: 16 }}>{i + 1}</span>
                  <p style={{ fontSize: 11, lineHeight: 1.65, margin: 0, color: '#1A3A7A' }}>{item}</p>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

// ── 예시 데이터 (변경감지 모드에서 Samsung 섹션 빈 경우) ──────────────────────
const EXAMPLE_CHANGES: Record<string, DataChange[]> = {
  Apple: [
    { url: 'https://www.apple.com/iphone/', site: 'Apple', tier: 'Tier 0', added: 42, removed: 18, title_changed: true, severity: 'Critical', severity_score: 88, change_types: ['SEO·AI 인덱싱', '헤드라인·슬로건'] },
    { url: 'https://www.apple.com/iphone-17-pro/', site: 'Apple', tier: 'Tier 1', added: 11, removed: 5, title_changed: false, severity: 'Medium', severity_score: 35, change_types: ['비주얼·미디어', '본문·기능 설명'] },
  ],
  Samsung: [
    { url: 'https://www.samsung.com/sg/smartphones/galaxy-s26-ultra/', site: 'Samsung', tier: 'Tier 0', added: 23, removed: 8, title_changed: false, severity: 'High', severity_score: 48, change_types: ['헤드라인·슬로건', '본문·기능 설명'] },
    { url: 'https://www.samsung.com/sg/galaxy-ai/', site: 'Samsung', tier: 'Tier 1', added: 6, removed: 3, title_changed: false, severity: 'Low', severity_score: 14, change_types: ['본문·기능 설명'] },
  ],
};

function SiteSection({ changes, site, isDemo }: { changes: DataChange[]; site: string; isDemo?: boolean }) {
  const cfg      = SITE_CONFIG[site] || SITE_CONFIG.Apple;
  const filtered = changes.filter(c => c.site === site);
  const showExample    = isDemo && filtered.length === 0;
  const displayChanges = showExample ? EXAMPLE_CHANGES[site] || [] : filtered;
  const isOurs         = site === 'Samsung';

  const hasCritical = !isOurs && filtered.some(c => c.severity === 'Critical');
  const hasHigh     = !isOurs && filtered.some(c => c.severity === 'High');
  const hasMedium   = !isOurs && filtered.some(c => c.severity === 'Medium');

  const alert = hasCritical ? { bg: '#FEF2F2', border: '#FECACA', dot: '#EF4444', color: '#991B1B', tag: '🚨', text: '즉시 확인 필요 항목 있음' }
              : hasHigh     ? { bg: '#FFF7ED', border: '#FED7AA', dot: '#F97316', color: '#92400E', tag: '⚠️', text: '모니터링 권장 항목 있음' }
              : hasMedium   ? { bg: '#FEFCE8', border: '#FEF08A', dot: '#EAB308', color: '#713F12', tag: '👀', text: '내용 확인 권장 항목 있음' }
              : null;

  return (
    <div style={{ ...CARD, overflow: 'visible' }}>
      <div style={{ padding: '12px 16px', background: cfg.accentBg, borderBottom: `1px solid ${cfg.accentBorder}`, borderRadius: '12px 12px 0 0', display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 17 }}>{cfg.emoji}</span>
        <p style={{ fontSize: 13, fontWeight: 700, margin: 0, color: cfg.accentColor, flex: 1 }}>{site}</p>
        {filtered.length > 0
          ? <span style={{ fontSize: 10, fontWeight: 700, color: cfg.accentColor, background: cfg.accentBg, padding: '2px 9px', borderRadius: 20, border: `1px solid ${cfg.accentBorder}` }}>{filtered.length}개 변경</span>
          : <span style={{ fontSize: 10, color: C.textMute, background: '#F3F4F6', padding: '2px 9px', borderRadius: 20, border: `1px solid ${C.border}` }}>변경 없음</span>
        }
      </div>
      {alert && (
        <div style={{ padding: '7px 16px', background: alert.bg, borderBottom: `1px solid ${alert.border}`, display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 13 }}>{alert.tag}</span>
          <span style={{ fontSize: 11, color: alert.color, fontWeight: 600 }}>{alert.text}</span>
        </div>
      )}
      {showExample && (
        <div style={{ margin: '10px 14px 0', padding: '7px 11px', background: C.blueBg, borderRadius: 8, border: `1px solid ${C.blueBorder}`, display: 'flex', alignItems: 'center', gap: 7 }}>
          <span style={{ fontSize: 12 }}>💡</span>
          <span style={{ fontSize: 10, color: '#1D4ED8' }}>변경 감지 시 아래와 같이 표시됩니다 <strong>(예시)</strong></span>
        </div>
      )}
      <div style={{ padding: '10px 14px 14px' }}>
        {displayChanges.length === 0 ? (
          <p style={{ fontSize: 12, color: C.textMute, textAlign: 'center', padding: '20px 0', margin: 0 }}>이번 크롤링에서 변화 없음</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, opacity: showExample ? 0.55 : 1 }}>
            {displayChanges.map((c, i) => <ChangeCard key={i} c={c} />)}
          </div>
        )}
      </div>
    </div>
  );
}

export default function MainPanel({ report, onRefresh, isDemo, isSnapshot }: Props) {
  const { analysis, data_changes, total_changed_urls } = report;

  // snapshot 모드: 전용 풀스크린 대시보드 렌더
  if (isSnapshot) {
    return <SnapshotDashboard report={report} onRefresh={onRefresh} isDemo={isDemo} />;
  }

  // 변경 감지 모드: 기존 레이아웃
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

      <div style={{ ...CARD, padding: '16px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <h1 style={{ fontSize: 16, fontWeight: 700, margin: '0 0 6px', color: C.text, letterSpacing: '-0.5px' }}>경쟁사 변화 분석 리포트</h1>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, alignItems: 'center' }}>
              <a href={report.url} target="_blank" rel="noopener noreferrer" style={{ fontSize: 11, color: C.blue, textDecoration: 'none' }}>{report.url}</a>
              <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 20, background: '#F3F4F6', color: C.textSub, border: `1px solid ${C.border}` }}>{report.tier}</span>
              {analysis?.priority_label && <SeverityBadge label={analysis.priority_label} />}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexShrink: 0 }}>
            <span style={{ fontSize: 10, color: C.textMute }}>{fmt(report.timestamp)}</span>
            {!isDemo && <button onClick={onRefresh} style={{ padding: '5px 12px', borderRadius: 8, border: `1px solid ${C.border}`, background: C.surface, cursor: 'pointer', fontSize: 11, color: C.text, fontWeight: 500 }}>새로고침</button>}
          </div>
        </div>
        <div style={{ marginTop: 12, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: C.blueBg, borderRadius: 8, padding: '5px 12px', border: `1px solid ${C.blueBorder}` }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: C.blue, display: 'inline-block' }} />
            <span style={{ fontSize: 11, color: '#1D4ED8', fontWeight: 600 }}>AI 분석 완료</span>
            <span style={{ fontSize: 11, color: '#60A5FA' }}>· {total_changed_urls}개 페이지 변경</span>
          </div>
          {isDemo && (
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: '#FFF7ED', borderRadius: 8, padding: '5px 12px', border: '1px solid #FED7AA' }}>
              <span style={{ fontSize: 12 }}>✦</span>
              <span style={{ fontSize: 11, color: '#92400E', fontWeight: 600 }}>예시 데이터</span>
            </div>
          )}
        </div>
      </div>

      {analysis && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <div style={{ ...CARD, padding: '16px 18px', borderTop: `3px solid ${C.text}` }}>
            <p style={{ fontSize: 10, fontWeight: 700, color: C.textSub, margin: '0 0 8px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>🔄 이번 변경 요약</p>
            <p style={{ fontSize: 12, color: C.text, lineHeight: 1.8, margin: 0 }}>{analysis.change_summary || '—'}</p>
          </div>
          <div style={{ ...CARD, padding: '16px 18px', borderTop: `3px solid ${C.blue}` }}>
            <p style={{ fontSize: 10, fontWeight: 700, color: '#1D4ED8', margin: '0 0 8px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>💡 인사이트 요약</p>
            <p style={{ fontSize: 12, color: C.text, lineHeight: 1.8, margin: 0 }}>{analysis.consumer_perception || '—'}</p>
          </div>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <SiteSection changes={data_changes} site="Apple"   isDemo={isDemo} />
        <SiteSection changes={data_changes} site="Samsung" isDemo={isDemo} />
      </div>

    </div>
  );
}
