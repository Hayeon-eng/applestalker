
"""
crawl_service_v2.py — 이벤트 기반 파이프라인 (안정화 + 디버그 유지 버전)
================================================================
✔ 기존 구조 100% 유지
✔ 0 pages → DELETE RUN 제거 (디버깅 가능)
✔ 실패해도 run 유지
✔ AEO 분석 유지
"""

from __future__ import annotations
import json
import uuid
from datetime import datetime
from typing import Any, Dict, List

from loguru import logger
from sqlalchemy import text

from config import SEED_TARGETS, load_active_urls, tier_for_url, target_for_url
from crawler import HybridCrawler
from diff_engine import DiffEngine, structural_signature, summarize_events
from intel_engine import IntelEngine, aeo_facts


def _s(v) -> str:
    return v if isinstance(v, str) else ("" if v is None else str(v))


def _content_hash(page: Dict[str, Any]) -> str:
    import hashlib
    blob = "|".join(_s(page.get(k)) for k in ("title", "h1", "meta_description", "body_content"))
    return hashlib.sha1(blob.encode("utf-8", "ignore")).hexdigest()


class CrawlServiceV2:
    def __init__(self, session_local, sync_engine, progress: Dict[str, Any] = None):
        self.SessionLocal = session_local
        self.sync_engine = sync_engine
        self.progress = progress if progress is not None else {}
        self.intel = IntelEngine()

    # ─────────────────────────────────────────────
    # SSE EVENT
    # ─────────────────────────────────────────────
    def _emit(self, **kw):
        ev = {"ts": datetime.utcnow().isoformat(), **kw}
        self.progress.setdefault("events", []).append(ev)

    # ─────────────────────────────────────────────
    # MAIN
    # ─────────────────────────────────────────────
    async def execute_crawl(self, site_key: str) -> Dict[str, Any]:
        target = SEED_TARGETS.get(site_key)
        if not target:
            raise ValueError(f"unknown site: {site_key}")

        run_id = f"{site_key}_{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:6]}"
        urls = self._load_db_urls(site_key)

        logger.info(f"[{run_id}] start {site_key}: {len(urls)} urls")
        self._emit(type="start", run_id=run_id, total=len(urls), site=site_key)

        # run 생성
        self._exec("""
            INSERT INTO crawl_runs
            (crawl_run_id, site_name, started_at, status, total_urls_discovered)
            VALUES (:r,:s,:t,'running',:n)
        """, r=run_id, s=site_key, t=datetime.utcnow(), n=len(urls))

        crawler = HybridCrawler()
        await crawler.start()

        crawled: List[Dict[str, Any]] = []
        all_events = []

        try:
            for entry in urls:
                url = entry["url"]
                tier = entry["tier_level"]

                try:
                    page = await crawler.crawl(url, requires_js=target.extraction.requires_js)
                except Exception as e:
                    self._emit(type="page_done", url=url, status="error", error=str(e))
                    continue

                if not page or page.get("error"):
                    self._emit(type="page_done", url=url, status="error", error=page.get("error"))
                    continue

                page["site_key"] = site_key
                page["tier_level"] = tier
                crawled.append(page)

                prev = self._load_previous_snapshot(url)
                events = self._diff(url, site_key, tier, page, prev, target)

                self._save_snapshot(run_id, site_key, url, page)

                for ev in events:
                    self._save_event(run_id, ev)

                all_events.extend(events)

                self._emit(
                    type="page_done",
                    url=url,
                    status="success",
                    changes=len(events),
                )

            # ─────────────────────────────────────────────
            # INTEL (항상 실행)
            # ─────────────────────────────────────────────
            summary = summarize_events(all_events)

            self._run_intel(
                run_id,
                site_key,
                target,
                crawled,
                [e.to_dict() for e in all_events],
                summary["max_level"] if all_events else "L0"
            )

            # ─────────────────────────────────────────────
            # RUN UPDATE
            # ─────────────────────────────────────────────
            self._exec("""
                UPDATE crawl_runs
                SET status='completed',
                    completed_at=:t,
                    total_urls_crawled=:c,
                    total_changes_detected=:ch
                WHERE crawl_run_id=:r
            """,
            t=datetime.utcnow(),
            c=len(crawled),
            ch=len(all_events),
            r=run_id)

            # ❗❗ 중요 수정: DELETE RUN 제거 (디버깅 가능하게 유지)
            if len(crawled) == 0:
                logger.warning(f"[{run_id}] 0 pages crawled → KEEP RUN for debugging")

            self._emit(type="done", run_id=run_id)

            return {
                "crawl_run_id": run_id,
                "status": "completed",
                "urls_crawled": len(crawled),
                "changes_detected": len(all_events),
            }

        except Exception as e:
            logger.error(f"[{run_id}] failed: {e}")

            self._exec("""
                UPDATE crawl_runs
                SET status='failed',
                    error_message=:m
                WHERE crawl_run_id=:r
            """, m=_s(e)[:480], r=run_id)

            self._emit(type="done", run_id=run_id, error=str(e))

            return {
                "crawl_run_id": run_id,
                "status": "failed",
                "error": _s(e)
            }

        finally:
            await crawler.close()

    # ─────────────────────────────────────────────
    # DIFF
    # ─────────────────────────────────────────────
    def _diff(self, url, site_key, tier, page, prev, target):
        if not prev:
            return []

        eng = DiffEngine(
            critical_keywords=target.sensitivity.critical_keywords,
            min_diff_ratio=target.sensitivity.min_text_diff_ratio
        )

        prev["_sig"] = prev.get("_sig") or {}
        return eng.detect(url, site_key, tier, page, prev)

    # ─────────────────────────────────────────────
    # INTEL
    # ─────────────────────────────────────────────
    def _run_intel(self, run_id, site_key, target, pages, event_dicts, max_level):
        try:
            res = self.intel.analyze_site(
                site_display=target.display_name,
                is_ours=target.is_ours,
                pages=pages,
                change_events=event_dicts,
                max_level=max_level
            )

            self._exec("""
                INSERT INTO povs
                (pov_run_id, related_crawl_run_id, observation, hypothesis,
                 opportunity, recommended_action, priority, functional_area, created_at)
                VALUES (:p,:r,:o,:h,:op,:a,:pr,:fa,:c)
            """,
            p=f"pov_{run_id}",
            r=run_id,
            o=_s(res.get("summary"))[:1900],
            h=_s(res.get("aeo_implications_for_samsung"))[:1900],
            op=_s(json.dumps(res.get("insights", []), ensure_ascii=False))[:1900],
            a=_s(json.dumps(res.get("action_items", []), ensure_ascii=False))[:1900],
            pr="high" if max_level in ("L4", "L5") else "medium",
            fa="AEO",
            c=datetime.utcnow())

        except Exception as e:
            logger.warning(f"intel save failed: {e}")

    # ─────────────────────────────────────────────
    # SNAPSHOT / EVENT (그대로 유지)
    # ─────────────────────────────────────────────
    def _load_previous_snapshot(self, url):
        try:
            with self.sync_engine.connect() as conn:
                row = conn.execute(text("""
                    SELECT title,h1,meta_description,canonical_url,body_content,
                           structural_signature,screenshot_phash
                    FROM page_snapshots
                    WHERE url=:u
                    ORDER BY crawled_at DESC
                    LIMIT 1
                """), {"u": url}).fetchone()

            if not row:
                return {}

            sig = json.loads(row[5]) if row[5] else {}

            return {
                "title": row[0],
                "h1": row[1],
                "meta_description": row[2],
                "canonical_url": row[3],
                "body_content": row[4],
                "_sig": sig,
                "screenshot_phash": row[6]
            }

        except Exception as e:
            logger.warning(f"snapshot load failed: {e}")
            return {}

    def _save_snapshot(self, run_id, site_key, url, page):
        try:
            sig = structural_signature(page)

            self._exec("""
                INSERT INTO page_snapshots
                (crawl_run_id, url, site_key, title, h1, meta_description,
                 canonical_url, body_content, structural_signature,
                 screenshot_phash, screenshot_thumb, content_hash,
                 word_count, crawled_at)
                VALUES (:r,:u,:s,:t,:h1,:md,:cu,:bc,:sig,:ph,:thumb,:ch,:wc,:ts)
            """,
            r=run_id, u=url, s=site_key,
            t=_s(page.get("title")),
            h1=_s(page.get("h1")),
            md=_s(page.get("meta_description")),
            cu=_s(page.get("canonical_url")),
            bc=_s(page.get("body_content")),
            sig=json.dumps(sig),
            ph=page.get("screenshot_phash"),
            thumb=page.get("screenshot_thumb"),
            ch=_content_hash(page),
            wc=int(page.get("word_count") or 0),
            ts=datetime.utcnow())

        except Exception as e:
            logger.warning(f"snapshot save failed: {e}")

    def _save_event(self, run_id, ev):
        try:
            self._exec("""
                INSERT INTO detected_changes
                (crawl_run_id, url, change_type, change_category,
                 field_name, before_value, after_value,
                 severity, severity_level, severity_reason,
                 summary, char_added, char_removed,
                 diff_ratio, evidence, tier_level, detected_at)
                VALUES (:r,:u,:ct,:cc,:fn,:bv,:av,:sev,:lv,:sr,:sm,:ca,:cr,:dr,:evd,:tl,:ts)
            """,
            r=run_id, u=ev.url,
            ct=ev.change_type,
            cc=ev.severity_level,
            fn=ev.field_name,
            bv=ev.before_value,
            av=ev.after_value,
            sev=ev.severity_legacy,
            lv=ev.severity_level,
            sr=ev.summary,
            sm=ev.summary,
            ca=ev.char_added,
            cr=ev.char_removed,
            dr=ev.diff_ratio,
            evd=json.dumps(ev.evidence, ensure_ascii=False),
            tl=ev.tier_level,
            ts=ev.detected_at)

        except Exception as e:
            logger.warning(f"event save failed: {e}")

    # ─────────────────────────────────────────────
    # DB
    # ─────────────────────────────────────────────
    def _exec(self, sql, **params):
        try:
            with self.sync_engine.connect() as conn:
                conn.execute(text(sql), params)
                conn.commit()
        except Exception as e:
            logger.warning(f"sql failed: {e}")

    def _load_db_urls(self, site_key):
        try:
            with self.sync_engine.connect() as conn:
                rows = conn.execute(text("""
                    SELECT url FROM monitored_urls
                    WHERE enabled=true AND site_key=:s
                """), {"s": site_key}).fetchall()

            return [{"url": r[0], "tier_level": "default"} for r in rows]

        except Exception:
            return []
