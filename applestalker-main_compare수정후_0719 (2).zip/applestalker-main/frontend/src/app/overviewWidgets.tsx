"use client";

import { useState } from "react";
import {
  MetricTab, MetricView, SiteKey, Change, AnalysisBlock, Report, UrlRow,
  METRICS, orderedSiteKeys, siteName, siteShortName, siteClass, levelKo, levelClass,
  shortUrl, bucketOf, actionForChange, metricActionSentence, metricIssueSentence, metricAreaLabel, siteMetricScore,
  PRODUCT_CATEGORY_ORDER, productCategoryKo, productCategoryFromRow,
  metricScoreBreakdown, scoreTier, ScoreTier, scoreTierEmoji, scoreTierLabel, shortActionPhrase, detailedAction,
} from "./shared";
import {
  compactSummary,
} from "./sectionCommon";

type HealthState = "good" | "watch" | "risk" | "unknown";
type PriorityLevel = "High" | "Medium" | "Low";

type MetricHealth = {
  state: HealthState;
  label: string;
  summary: string;
};

type SiteDashboardRow = {
  site: SiteKey;
  collection: MetricHealth;
  metrics: Record<MetricTab, MetricHealth>;
  blocks: Partial<Record<MetricTab, AnalysisBlock | undefined>>;
  priority: PriorityLevel;
  issue: string;
  action: string;
  changes: Change[];
};

type PriorityIssue = {
  id: string;
  priority: PriorityLevel;
  site: SiteKey;
  area: string;
  issue: string;
  action: string;
  source: "change" | "insight" | "evidence";
  metric: MetricTab;
  change?: Change;
};

type AxisComponentStat = { label: string; value: number | null; competitorAvg: number | null; delta: number | null };
type AxisHighlight = {
  metric: MetricTab;
  score: number | null;
  tier: ScoreTier;
  competitorAvg: number | null;
  delta: number | null; // Samsung score - 경쟁사 평균
  keyStatLabel: string;
  keyStatValue: number | null;
  componentStats: AxisComponentStat[];
  insight: string;
  action: string;
  change?: Change;
};

export type BoardDigest = {
  scopedMetrics: MetricTab[];
  allSites: SiteKey[];
  siteRows: SiteDashboardRow[];
  priorityRows: PriorityIssue[];
  axisHighlights: AxisHighlight[];
  samsungActions: string[];
  competitorBenchmarks: string[];
  evidenceWarnings: string[];
  headline: string;
  lead: string;
  overallLabel: string;
  confidenceLabel: string;
  executiveBullets: string[];
  comparableCount: number;
  watchCount: number;
  riskCount: number;
  unknownCount: number;
  highChangeCount: number;
  actionCount: number;
};

const HEALTH_META: Record<HealthState, { label: string; cls: string }> = {
  good: { label: "우수", cls: "good" },
  watch: { label: "확인 필요", cls: "watch" },
  risk: { label: "개선 필요", cls: "risk" },
  unknown: { label: "근거 부족", cls: "unknown" },
};

const priorityRank: Record<PriorityLevel, number> = { High: 0, Medium: 1, Low: 2 };
const healthPriorityRank: Record<HealthState, number> = { risk: 0, unknown: 1, watch: 2, good: 3 };

const metricShortLabel = (metric: MetricTab) => metric === "data" ? "DATA" : metric === "copy" ? "COPY" : "VISUAL";

const asNumber = (v: unknown, fallback = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
};

const pageCountFromBlock = (metric: MetricTab, block?: AnalysisBlock): number => {
  const f: any = block?.facts || {};
  if (metric === "data") return asNumber(f.schema?.total_pages, 0);
  if (metric === "copy") {
    const inv = asNumber(f.page_inventory?.total_pages, 0);
    const pages = Array.isArray(f.copy_richness?.all_pages) ? f.copy_richness.all_pages.length : 0;
    return inv || pages;
  }
  const roleSummary = f.visual_tactics?.role_summary || {};
  const rolePages = Object.values(roleSummary).reduce((sum: number, x: any) => sum + asNumber(x?.pages, 0), 0);
  const tacticPages = Array.isArray(f.visual_tactics?.pages) ? f.visual_tactics.pages.length : 0;
  return rolePages || tacticPages;
};

const avgCopyWords = (block?: AnalysisBlock): number | null => {
  const pages = (block?.facts as any)?.copy_richness?.all_pages;
  if (!Array.isArray(pages) || pages.length === 0) return null;
  const total = pages.reduce((sum: number, p: any) => sum + asNumber(p?.word_count, 0), 0);
  return Math.round(total / pages.length);
};

const avgCopyScore = (block?: AnalysisBlock): number | null => {
  const pages = (block?.facts as any)?.copy_richness?.all_pages;
  if (!Array.isArray(pages) || pages.length === 0) return null;
  const total = pages.reduce((sum: number, p: any) => sum + asNumber(p?.score, 0), 0);
  return Math.round((total / pages.length) * 10) / 10;
};

const visualImageCount = (block?: AnalysisBlock): number | null => {
  const v = (block?.facts as any)?.image_diversity?.total_images;
  return typeof v === "number" ? v : null;
};

const visualAltPct = (block?: AnalysisBlock): number | null => {
  const v = (block?.facts as any)?.alt_text_quality?.descriptive_ratio_pct;
  return typeof v === "number" ? v : null;
};

const schemaCoverage = (block?: AnalysisBlock): number | null => {
  const v = (block?.facts as any)?.schema?.coverage_pct;
  return typeof v === "number" ? v : null;
};

const worstHealth = (states: HealthState[]): HealthState => {
  if (!states.length) return "unknown";
  return [...states].sort((a, b) => healthPriorityRank[a] - healthPriorityRank[b])[0];
};

function metricHealth(metric: MetricTab, block: AnalysisBlock | undefined, metricChanges: Change[]): MetricHealth {
  const high = metricChanges.some((c) => c.level === "High");
  const changed = metricChanges.length > 0;
  if (!block) return { state: "unknown", label: "근거 부족", summary: `${metricAreaLabel(metric)} 근거가 부족합니다` };

  if (metric === "data") {
    const totalPages = pageCountFromBlock(metric, block);
    const coverage = schemaCoverage(block);
    const h1Pct = asNumber((block.facts as any)?.html_structure?.h_tag_coverage?.h1_coverage_pct, 0);
    if (!totalPages) return { state: "unknown", label: "근거 부족", summary: "DATA / Schema 페이지 근거가 부족합니다" };
    if (high) return { state: "risk", label: "변화 있음", summary: "Schema/H-tag 변경이 검색·AI 해석에 영향을 줄 수 있습니다" };
    if (coverage === 0 && h1Pct === 0) return { state: "risk", label: "주의 필요", summary: "Schema와 H-tag 역할 신호 적용 범위가 제한적입니다" };
    if ((coverage ?? 0) < 40) return { state: "watch", label: "확인 필요", summary: `Schema 적용 범위가 낮습니다 (${coverage ?? "-"}%)` };
    return { state: changed ? "watch" : "good", label: changed ? "변화 있음" : "우수", summary: `Schema 적용 ${coverage ?? "-"}% · 역할 신호 양호` };
  }

  if (metric === "copy") {
    const totalPages = pageCountFromBlock(metric, block);
    const words = avgCopyWords(block);
    const score = avgCopyScore(block);
    const cta = asNumber((block.facts as any)?.commerce_cta?.pages_with_buy_cta, 0);
    const roles = (block.facts as any)?.page_inventory?.by_page_role || {};
    const conversionRoles = asNumber(roles.pf, 0) + asNumber(roles.pdp, 0) + asNumber(roles.buying, 0);
    if (!totalPages) return { state: "unknown", label: "근거 부족", summary: "COPY / CTA 페이지 근거가 부족합니다" };
    if (words !== null && words < 30) return { state: "unknown", label: "근거 부족", summary: "카피 본문 근거가 부족합니다" };
    if (high) return { state: "risk", label: "변화 있음", summary: "핵심 카피/CTA 변경을 확인해야 합니다" };
    if ((score !== null && score < 40) || (conversionRoles > 0 && cta === 0)) {
      return { state: "risk", label: "주의 필요", summary: "구매 CTA와 카피 연결 범위가 제한적입니다" };
    }
    return { state: changed ? "watch" : "good", label: changed ? "변화 있음" : "우수", summary: `카피 구체성 ${score ?? "-"}점 · 구매 CTA 보유 ${cta}페이지` };
  }

  const totalPages = pageCountFromBlock(metric, block);
  const imageCount = visualImageCount(block);
  const altPct = visualAltPct(block);
  if (!totalPages) return { state: "unknown", label: "근거 부족", summary: "VISUAL / ALT COPY 페이지 근거가 부족합니다" };
  if (imageCount === 0) return { state: "unknown", label: "근거 부족", summary: "이미지/ALT COPY 근거가 부족합니다" };
  if (high) return { state: "risk", label: "변화 있음", summary: "핵심 이미지/ALT COPY 변경을 확인해야 합니다" };
  if ((altPct ?? 0) < 40) return { state: "risk", label: "주의 필요", summary: "ALT COPY의 구체성이 상대적으로 낮습니다" };
  return { state: changed ? "watch" : "good", label: changed ? "변화 있음" : "우수", summary: `이미지 ${imageCount ?? "-"}개 · ALT COPY ${altPct ?? "-"}%` };
}

function collectionHealth(site: SiteKey, scopedMetrics: MetricTab[], dcv: Report["dcv"] | undefined, siteChanges: Change[]): MetricHealth {
  const allBlocks = (['data', 'copy', 'visual'] as MetricTab[]).map((m) => dcv?.[m]?.[site]).filter(Boolean);
  if (allBlocks.length === 0) return { state: "unknown", label: "근거 없음", summary: "수집 근거 없음" };

  const copyBlock = dcv?.copy?.[site];
  const visualBlock = dcv?.visual?.[site];
  const dataBlock = dcv?.data?.[site];
  const words = avgCopyWords(copyBlock);
  const images = visualImageCount(visualBlock);
  const totalPages = Math.max(
    pageCountFromBlock("data", dataBlock),
    pageCountFromBlock("copy", copyBlock),
    pageCountFromBlock("visual", visualBlock),
  );
  const missingScoped = scopedMetrics.filter((m) => !dcv?.[m]?.[site]);
  const high = siteChanges.some((c) => c.level === "High");

  if (!totalPages) return { state: "unknown", label: "근거 부족", summary: "핵심 비교에 넣기 전 원본 페이지 확인이 필요합니다" };
  if (words !== null && words < 30 && (images === 0 || images === null)) {
    return { state: "unknown", label: "근거 부족", summary: "본문/이미지 근거가 부족해 보조 확인으로 분리합니다" };
  }
  if (high) return { state: "watch", label: "변화 있음", summary: "High 변경 포함" };
  if (missingScoped.length > 0) {
    return { state: "watch", label: "확인 필요", summary: `${missingScoped.map(metricShortLabel).join("/")} 근거를 보강하세요` };
  }
  if (words !== null && words < 80) return { state: "watch", label: "확인 필요", summary: "카피 근거가 짧아 핵심 문구를 확인하세요" };
  if (scopedMetrics.includes("visual") && images === 0) return { state: "watch", label: "확인 필요", summary: "이미지/ALT COPY 근거를 확인하세요" };
  return { state: "good", label: "우수", summary: `${totalPages}p 근거 확보` };
}

function issueFromRow(row: SiteDashboardRow): string {
  if (row.changes.length) return compactSummary(row.changes[0].summary || row.changes[0].field || "변경 상세 확인 필요", 90);
  if (row.collection.state === "risk" || row.collection.state === "unknown") return row.collection.summary;
  const weakMetric = (Object.entries(row.metrics) as [MetricTab, MetricHealth][]).find(([, h]) => h.state === "risk" || h.state === "unknown" || h.state === "watch");
  if (weakMetric) return `${metricShortLabel(weakMetric[0])}: ${weakMetric[1].summary}`;
  return "중요 변경 없음 · 현재 구성을 유지";
}

function actionFromRow(row: SiteDashboardRow): string {
  if (row.changes.length) return actionForChange(row.changes[0]);
  const weakMetric = (Object.entries(row.metrics) as [MetricTab, MetricHealth][]).find(([, h]) => h.state === "risk" || h.state === "watch" || h.state === "unknown");
  if (weakMetric) return detailedAction(weakMetric[0], row.blocks[weakMetric[0]]);
  if (row.collection.state === "risk" || row.collection.state === "unknown") return "핵심 비교에서는 제외하고 URL·리다이렉트·렌더링 상태를 확인하세요.";
  return "현재 구성을 유지하고 다음 수집에서 변화만 확인하세요.";
}

function buildSiteRows(changes: Change[], dcv: Report["dcv"] | undefined, scopedMetrics: MetricTab[], expectedSites: SiteKey[]) {
  const allSites = orderedSiteKeys([
    ...expectedSites,
    ...scopedMetrics.flatMap((m) => Object.keys(dcv?.[m] || {})),
    ...changes.map((c) => c.site || ""),
  ]);

  return allSites.map((site) => {
    const siteChanges = changes.filter((c) => c.site === site);
    const metrics = {
      data: metricHealth("data", dcv?.data?.[site], siteChanges.filter((c) => bucketOf(c) === "data")),
      copy: metricHealth("copy", dcv?.copy?.[site], siteChanges.filter((c) => bucketOf(c) === "copy")),
      visual: metricHealth("visual", dcv?.visual?.[site], siteChanges.filter((c) => bucketOf(c) === "visual")),
    };
    const collection = collectionHealth(site, scopedMetrics, dcv, siteChanges);
    const worstScoped = worstHealth(scopedMetrics.map((m) => metrics[m].state));
    const maxChangeLevel = siteChanges.some((c) => c.level === "High") ? "High" : siteChanges.some((c) => c.level === "Medium") ? "Medium" : undefined;
    const priority: PriorityLevel = maxChangeLevel === "High" || collection.state === "risk" || collection.state === "unknown" || worstScoped === "risk" || worstScoped === "unknown"
      ? "High"
      : maxChangeLevel === "Medium" || collection.state === "watch" || worstScoped === "watch"
      ? "Medium"
      : "Low";
    const blocks: Partial<Record<MetricTab, AnalysisBlock | undefined>> = {
      data: dcv?.data?.[site], copy: dcv?.copy?.[site], visual: dcv?.visual?.[site],
    };
    const row: SiteDashboardRow = {
      site, metrics, blocks, collection, priority, changes: siteChanges,
      issue: "", action: "",
    };
    row.issue = issueFromRow(row);
    row.action = actionFromRow(row);
    return row;
  });
}

function buildPriorityRows(rows: SiteDashboardRow[], changes: Change[], scopedMetrics: MetricTab[]): PriorityIssue[] {
  const changeRows = [...changes]
    .sort((a, b) => priorityRank[(a.level || "Low") as PriorityLevel] - priorityRank[(b.level || "Low") as PriorityLevel])
    .slice(0, 6)
    .map((c) => ({
      id: `change-${c.id}`,
      priority: (c.level || "Low") as PriorityLevel,
      site: c.site || "",
      area: METRICS[bucketOf(c)].label,
      issue: compactSummary(c.summary || c.field || "변경 상세 확인 필요", 90),
      action: actionForChange(c),
      source: "change" as const,
      metric: bucketOf(c),
      change: c,
    }));

  const samsungRowForCompare = rows.find((r) => r.site === "samsung");
  const insightRows = rows
    .filter((row) => row.priority !== "Low" && !changeRows.some((x) => x.site === row.site))
    .sort((a, b) => priorityRank[a.priority] - priorityRank[b.priority])
    .slice(0, 6)
    .map((row) => {
      const weakMetric = scopedMetrics.find((m) => row.metrics[m].state === "risk" || row.metrics[m].state === "unknown" || row.metrics[m].state === "watch");
      const samsungMetric = weakMetric ? samsungRowForCompare?.metrics[weakMetric] : undefined;
      const action = !weakMetric
        ? row.action
        : row.site === "samsung"
          ? detailedAction(weakMetric, row.blocks[weakMetric])
          : samsungMetric && samsungMetric.state === "good"
            ? `Samsung은 이 항목(${samsungMetric.summary})이 이미 경쟁사 대비 양호한 수준이라 별도 조치 없이 유지하면 됩니다.`
            : samsungMetric && samsungMetric.state === "watch"
              ? `Samsung도 ${METRICS[weakMetric].label}이 완전하지 않으니, 함께 점검하세요: ${detailedAction(weakMetric, samsungRowForCompare?.blocks[weakMetric])}`
              : detailedAction(weakMetric, row.blocks[weakMetric]);
      return {
        id: `insight-${row.site}`,
        priority: row.priority,
        site: row.site,
        area: weakMetric ? METRICS[weakMetric].label : "근거 상태",
        issue: weakMetric ? row.metrics[weakMetric].summary : row.issue,
        action,
        source: row.collection.state === "unknown" ? "evidence" as const : "insight" as const,
        metric: weakMetric || scopedMetrics[0] || "copy",
        change: row.changes[0],
      };
    });

  return [...changeRows, ...insightRows]
    .sort((a, b) => priorityRank[a.priority] - priorityRank[b.priority])
    .slice(0, 8);
}

function actionLinesForRow(row: SiteDashboardRow, scopedMetrics: MetricTab[]): string[] {
  const lines: string[] = [];
  const changed = row.changes.slice(0, 2).map((c) => actionForChange(c));
  lines.push(...changed);
  scopedMetrics.forEach((m) => {
    const health = row.metrics[m];
    if (health.state === "risk" || health.state === "watch") {
      lines.push(`${metricIssueSentence(m)} ${detailedAction(m, row.blocks[m])}`);
    }
  });
  if (!lines.length && (row.collection.state === "risk" || row.collection.state === "unknown")) {
    lines.push(`${siteShortName(row.site)}는 근거가 부족해 핵심 비교에서 제외하고 원본 URL·렌더링을 확인하세요.`);
  }
  if (!lines.length) lines.push(`${siteShortName(row.site)}는 중요 변경이 없어 현재 구성을 유지하세요.`);
  return Array.from(new Set(lines));
}

function benchmarkLineForRow(row: SiteDashboardRow, scopedMetrics: MetricTab[]): string {
  const bestMetric = scopedMetrics.find((m) => row.metrics[m].state === "good") || scopedMetrics.find((m) => row.metrics[m].state === "watch") || scopedMetrics[0];
  if (bestMetric === "data") return `${siteShortName(row.site)}는 DATA / Schema 구조를 참고할 수 있습니다. Samsung의 PF/PDP/Buying 역할별 Schema와 비교하세요.`;
  if (bestMetric === "visual") return `${siteShortName(row.site)}는 VISUAL / ALT COPY 흐름을 참고할 수 있습니다. 제품명·기능·사용 장면 설명 방식을 비교하세요.`;
  return `${siteShortName(row.site)}는 COPY / CTA 흐름을 참고할 수 있습니다. PDP에서 구매/혜택 CTA가 어떻게 이어지는지 비교하세요.`;
}

// 각 축이 '실제로 재는 것'을 주어로 (COPY는 구매페이지 존재가 아니라 카피·CTA 충실도 점수)
const AXIS_INSIGHT_SUBJECT: Record<MetricTab, string> = {
  data: "Schema·페이지 구조 신호",
  copy: "카피·CTA 충실도",
  visual: "이미지·ALT 텍스트 충실도",
};
const AXIS_INSIGHT_MEANING: Record<MetricTab, string> = {
  data: "검색 엔진이 페이지 역할을 해석하는 신호 범위에 영향을 줍니다.",
  copy: "페이지 수보다 실제 카피의 구체성·분량 차이가 전환에 더 크게 작용합니다.",
  visual: "이미지의 의미 전달 범위에 영향을 줍니다.",
};

function buildAxisInsight(metric: MetricTab, delta: number | null, tier: ScoreTier): string {
  const subj = AXIS_INSIGHT_SUBJECT[metric];
  const meaning = AXIS_INSIGHT_MEANING[metric];
  if (delta == null) {
    return `${subj}은 경쟁사 평균과 비교할 근거가 아직 부족합니다. ${meaning}`;
  }
  if (delta > 0) {
    const nuance = tier !== "good"
      ? ` 다만 절대 점수 기준으로는 아직 ${scoreTierLabel(tier)} 구간이라 개선 여지가 있습니다.`
      : "";
    return `${subj} 점수는 경쟁사 평균보다 ${delta}%p 높습니다(우위).${nuance} ${meaning}`;
  }
  if (delta < 0) {
    return `${subj} 점수는 경쟁사 평균보다 ${Math.abs(delta)}%p 낮습니다(열위). ${meaning}`;
  }
  return `${subj} 점수는 경쟁사 평균과 비슷한 수준입니다. ${meaning}`;
}

function buildAxisHighlights(
  dcv: Report["dcv"] | undefined, allSites: SiteKey[], scopedMetrics: MetricTab[], changes: Change[],
): AxisHighlight[] {
  return scopedMetrics.map((metric): AxisHighlight => {
    const samsungBlock = dcv?.[metric]?.["samsung"];
    const samsungBreak = metricScoreBreakdown(metric, samsungBlock);
    const score = samsungBreak.total;
    const tier = scoreTier(score);

    const competitorBreakdowns = allSites
      .filter((s) => s !== "samsung")
      .map((s) => metricScoreBreakdown(metric, dcv?.[metric]?.[s]));
    const competitorScores = competitorBreakdowns.map((b) => b.total).filter((v): v is number => v != null);
    const competitorAvg = competitorScores.length
      ? Math.round(competitorScores.reduce((a, b) => a + b, 0) / competitorScores.length) : null;
    const delta = score != null && competitorAvg != null ? score - competitorAvg : null;

    // 하위지표(예: Copy richness/CTA coverage/Word coverage) 각각을 경쟁사 평균과 함께 — CTA 하나만 부각되지 않도록 3개 다 계산
    const componentStats: AxisComponentStat[] = samsungBreak.components.map((c) => {
      const peerVals = competitorBreakdowns
        .map((b) => b.components.find((x) => x.label === c.label)?.value ?? null)
        .filter((v): v is number => v != null);
      const peerAvg = peerVals.length ? Math.round(peerVals.reduce((a, b) => a + b, 0) / peerVals.length) : null;
      const compDelta = c.value != null && peerAvg != null ? c.value - peerAvg : null;
      return { label: c.label, value: c.value, competitorAvg: peerAvg, delta: compDelta };
    });

    const weakestComponent = [...samsungBreak.components]
      .filter((c) => c.value != null)
      .sort((a, b) => (a.value as number) - (b.value as number))[0];

    const samsungChange = changes
      .filter((c) => c.site === "samsung" && bucketOf(c) === metric)
      .sort((a, b) => priorityRank[(a.level || "Low") as PriorityLevel] - priorityRank[(b.level || "Low") as PriorityLevel])[0];

    const aheadButModerate = delta != null && delta > 0 && tier !== "good";
    const action = samsungChange
      ? actionForChange(samsungChange)
      : aheadButModerate
        ? `경쟁 우위는 유지하면서 ${detailedAction(metric, samsungBlock)}`
        : detailedAction(metric, samsungBlock);

    return {
      metric, score, tier, competitorAvg, delta,
      keyStatLabel: weakestComponent?.label || METRICS[metric].label,
      keyStatValue: weakestComponent?.value ?? score,
      componentStats,
      insight: buildAxisInsight(metric, delta, tier),
      action,
      change: samsungChange,
    };
  });
}

export function buildDashboardDigest({
  changes, dcv, metricTab, expectedSites = [],
}: {
  changes: Change[]; dcv?: Report["dcv"]; metricTab: MetricView; expectedSites?: SiteKey[];
}): BoardDigest {
  const scopedMetrics = metricTab === "all" ? (["data", "copy", "visual"] as MetricTab[]) : [metricTab];
  const siteRows = buildSiteRows(changes, dcv, scopedMetrics, expectedSites);
  const allSites = siteRows.map((row) => row.site);
  const highChangeCount = changes.filter((c) => c.level === "High").length;
  const comparableCount = siteRows.filter((row) => row.collection.state === "good" || row.collection.state === "watch").length;
  const watchCount = siteRows.filter((row) => row.collection.state === "watch").length;
  const riskCount = siteRows.filter((row) => row.collection.state === "risk").length;
  const unknownCount = siteRows.filter((row) => row.collection.state === "unknown").length;
  const priorityRows = buildPriorityRows(siteRows, changes, scopedMetrics);
  const axisHighlights = buildAxisHighlights(dcv, allSites, scopedMetrics, changes);
  const actionCount = priorityRows.filter((row) => row.priority !== "Low").length;

  const samsungRow = siteRows.find((row) => row.site === "samsung");
  const samsungActions = samsungRow
    ? actionLinesForRow(samsungRow, scopedMetrics).slice(0, 4)
    : ["Samsung 관리 URL과 수집 결과가 없어 개선 포인트를 만들 수 없습니다."];
  const competitorBenchmarks = siteRows
    .filter((row) => row.site !== "samsung" && row.collection.state !== "unknown")
    .sort((a, b) => priorityRank[a.priority] - priorityRank[b.priority])
    .slice(0, 4)
    .map((row) => benchmarkLineForRow(row, scopedMetrics));
  const evidenceWarnings = siteRows
    .filter((row) => row.collection.state === "unknown" || row.metrics && scopedMetrics.some((m) => row.metrics[m].state === "unknown"))
    .slice(0, 4)
    .map((row) => `${siteShortName(row.site)}는 근거가 부족해 핵심 인사이트가 아니라 보조 확인으로 보세요.`);

  const headline = !allSites.length
    ? "분석 데이터 없음"
    : highChangeCount > 0
    ? `오늘 확인할 변화 ${highChangeCount}건`
    : changes.length > 0
    ? `경쟁사 변화 ${changes.length}건 확인`
    : "오늘의 경쟁사 인사이트";
  const lead = !allSites.length
    ? "관리 URL을 추가하거나 수집을 실행하면 인사이트와 액션이 표시됩니다."
    : `${metricTab === "all" ? "전체 분석" : METRICS[metricTab as MetricTab].label} 기준으로 Samsung 개선 포인트, 경쟁사 벤치마크, 근거 부족 항목을 분리했습니다.`;
  const overallLabel = !allSites.length
    ? "데이터 없음"
    : highChangeCount > 0 || samsungActions.some((x) => !/유지/.test(x))
    ? "오늘 확인"
    : changes.length > 0
    ? "변화 확인"
    : "유지";
  const confidenceLabel = evidenceWarnings.length ? "근거 보강 필요" : "근거 확보";

  const changedSites = orderedSiteKeys(changes.map((c) => c.site || "")).slice(0, 4).map(siteShortName);
  const executiveBullets = [
    samsungActions[0] || "Samsung 개선 포인트가 없습니다.",
    competitorBenchmarks[0] || "현재 비교 가능한 경쟁사 벤치마크가 없습니다.",
    changes.length
      ? `변화 감지: ${changedSites.join(", ") || "상세 목록"} 중심으로 확인하세요.`
      : "큰 변경은 없으므로 액션과 벤치마크 포인트만 확인하세요.",
  ];

  return {
    scopedMetrics, allSites, siteRows, priorityRows, axisHighlights, samsungActions, competitorBenchmarks, evidenceWarnings,
    headline, lead, overallLabel, confidenceLabel, executiveBullets,
    comparableCount, watchCount, riskCount, unknownCount, highChangeCount, actionCount,
  };
}

/* WatchPointPanel — Site별 분석(pagesSection) 탭과 같은 "카드 여러 개를 쌓는" 톤으로 통일.
   ① 요약 3줄 스트립 ② Site별 인사이트(클릭 → 상세로 이동) ③ 액션 표(클릭 → 상세로 이동)
   ④ 매트릭스는 접어서 보관(원하는 사람만 펼쳐봄). 헤드라인/KPI는 상위 summaryCard와 중복이라 제거. */
export function WatchPointPanel({
  changes, dcv, metricTab, expectedSites = [], onJumpToMetric,
}: {
  changes: Change[]; dcv?: Report["dcv"]; metricTab: MetricView; expectedSites?: SiteKey[];
  onJumpToMetric?: (m: MetricTab, change?: Change) => void;
}) {
  const digest = buildDashboardDigest({ changes, dcv, metricTab, expectedSites });
  const jump = (metric: MetricTab, change?: Change) => onJumpToMetric?.(metric, change);

  return (
    <>
      {/* ① 축별 핵심 발견 — DATA/COPY/VISUAL 3장 고정, 항상 Samsung 자체 점수 기준.
         제목 → 점수+신호등 → 핵심 수치(경쟁사 평균 대비) → 인사이트(관찰→비교→의미) → 우선 액션 */}
      <div className="card">
        <p className="cardTitle">축별 핵심 발견 <span className="cardTitleHint">— 누르면 해당 탭·상세로 이동</span></p>
        <div className="axisGrid">
          {digest.axisHighlights.map((h) => (
            <button key={h.metric} className="axisCard" onClick={() => jump(h.metric, h.change)}>
              <p className="axisCardLabel">{metricShortLabel(h.metric)}</p>
              <p className="axisCardScore">
                <span>{scoreTierEmoji(h.tier)}</span>
                <span className="axisCardScoreNum">{h.score == null ? "-" : h.score}</span>
                <span className="axisCardTier">{scoreTierLabel(h.tier)}</span>
              </p>
              <div className="axisCardStatList">
                {h.componentStats.map((c) => (
                  <p key={c.label} className="axisCardStatLine">
                    <span className="axisCardStatLabel">{c.label}</span>
                    <span className="axisCardStatVal">{c.value == null ? "근거 없음" : `${c.value}%`}</span>
                    {c.delta != null && (
                      <span className={c.delta < 0 ? "axisCardDeltaBad" : "axisCardDeltaGood"}>
                        {c.delta > 0 ? "+" : ""}{c.delta}%p vs 경쟁사 평균
                      </span>
                    )}
                  </p>
                ))}
              </div>
              <p className="axisCardInsight">{h.insight}</p>
              <hr className="axisCardHr" />
              <p className="axisCardAct">우선 액션: {h.action}</p>
            </button>
          ))}
        </div>
      </div>

      {/* ② 전체 액션 — 위 축 카드는 하이라이트 3건, 여기는 전체 목록 (용도가 다름) */}
      <div className="card">
        <p className="cardTitle">전체 액션 ({digest.priorityRows.length}건)</p>
        <div className="priorityTableWrap">
          <div className="priorityRow head">
            <span>우선순위</span><span>Site</span><span>영역</span><span>판단</span><span>액션</span>
          </div>
          {digest.priorityRows.length === 0 ? (
            <div className="priorityEmpty">액션 없음 · 현재 구성을 유지</div>
          ) : digest.priorityRows.map((row) => (
            <button key={row.id} className="priorityRow" onClick={() => jump(row.metric, row.change)}>
              <span><span className={`sevBadge ${levelClass(row.priority)}`}>{levelKo(row.priority)}</span></span>
              <span><span className={`badge ${siteClass(row.site)}`}>{siteName(row.site)}</span></span>
              <span>{row.area}</span>
              <span>{row.issue}</span>
              <span>{row.action}</span>
            </button>
          ))}
        </div>
      </div>
    </>
  );
}

type QaResultRow = {
  site: SiteKey; metric: MetricTab; score: number | null; tier: ScoreTier;
  components: { label: string; value: number | null }[];
  health: MetricHealth; evidenceItems: { url: string; text: string }[];
};

// S10: Quick view — 경쟁사 평균(삼성 제외)/제품 평균(전체) 및 하위 항목 평균 계산
type QaMetricAvg = { compTotal: number | null; prodTotal: number | null; compComp: Record<string, number | null> };
function computeMetricAverages(dcv?: Report["dcv"]): Record<MetricTab, QaMetricAvg> {
  const mk = (m: MetricTab): QaMetricAvg => {
    const blocks = (dcv?.[m] || {}) as Record<string, any>;
    const keys = Object.keys(blocks);
    const compKeys = keys.filter((s) => s !== "samsung");
    const totalOf = (ks: string[]) => {
      const vals = ks.map((s) => metricScoreBreakdown(m, blocks[s]).total).filter((v): v is number => v != null);
      return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null;
    };
    const acc: Record<string, number[]> = {};
    compKeys.forEach((s) => metricScoreBreakdown(m, blocks[s]).components.forEach((c) => {
      if (c.value != null) (acc[c.label] = acc[c.label] || []).push(c.value);
    }));
    const compComp: Record<string, number | null> = {};
    Object.entries(acc).forEach(([k, arr]) => { compComp[k] = arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : null; });
    return { compTotal: totalOf(compKeys), prodTotal: totalOf(keys), compComp };
  };
  return { data: mk("data"), copy: mk("copy"), visual: mk("visual") };
}

const deltaMark = (d: number | null): string => d == null ? "" : d > 0 ? ` (▲+${d})` : d < 0 ? ` (▼${d})` : " (≈)";

export function InsightChat({ dcv, changes, expectedSites = [], urls = [], onNavigateSite }: { dcv?: Report["dcv"]; changes: Change[]; expectedSites?: SiteKey[]; urls?: UrlRow[]; onNavigateSite?: (site: SiteKey) => void }) {
  const [open, setOpen] = useState(false);
  const [qaSite, setQaSite] = useState<string>("all");
  const [qaMetric, setQaMetric] = useState<string>("all");
  const [qaCategory, setQaCategory] = useState<string>("all");
  const [results, setResults] = useState<QaResultRow[] | null>(null);
  const [resultLabel, setResultLabel] = useState<string>("");

  const allQaSites = orderedSiteKeys([...expectedSites, ...Object.keys(dcv?.data || {}), ...Object.keys(dcv?.copy || {}), ...Object.keys(dcv?.visual || {}), ...changes.map((c) => c.site || "")]);

  // 선택된 브랜드가 실제로 보유한 제품군만 — Garmin처럼 워치만 파는 브랜드는 워치만 보여야 함
  const categoriesForSite = (site: string): string[] => {
    if (site === "all") return PRODUCT_CATEGORY_ORDER;
    const siteUrls = urls.filter((u) => u.site_key === site);
    const cats = Array.from(new Set(siteUrls.map((u) => productCategoryFromRow(u, u.url)).filter(Boolean)));
    return cats.length ? PRODUCT_CATEGORY_ORDER.filter((c) => cats.includes(c)) : PRODUCT_CATEGORY_ORDER;
  };
  const availableCategories = categoriesForSite(qaSite);

  const handleQaSiteChange = (site: string) => {
    setQaSite(site);
    const nextCats = categoriesForSite(site);
    if (qaCategory !== "all" && !nextCats.includes(qaCategory)) setQaCategory("all");
  };

  const askStructured = () => {
    const metricsToShow = qaMetric === "all" ? (["data", "copy", "visual"] as MetricTab[]) : [qaMetric as MetricTab];
    const sitesToShow = qaSite === "all" ? allQaSites : [qaSite as SiteKey];
    if (!sitesToShow.length) {
      setResults([]);
      setResultLabel("표시할 사이트가 없습니다. 관리 URL을 추가하고 수집을 실행하세요.");
      return;
    }
    const rows: QaResultRow[] = sitesToShow.flatMap((s) =>
      metricsToShow.map((m) => {
        const block = dcv?.[m]?.[s];
        const breakdown = metricScoreBreakdown(m, block);
        const sChanges = changes.filter((c) => bucketOf(c) === m && c.site === s
          && (qaCategory === "all" || productCategoryFromRow(undefined, c.url) === qaCategory))
          .sort((a, b) => priorityRank[(a.level || "Low") as PriorityLevel] - priorityRank[(b.level || "Low") as PriorityLevel]);
        const health = metricHealth(m, block, sChanges);
        const evidenceItems = sChanges.length
          ? sChanges.slice(0, 5).map((c) => ({ url: c.url || "", text: `${levelKo((c.level || "Low") as PriorityLevel)} · ${c.summary || c.field || "변경 감지"}` }))
          : [];
        return { site: s, metric: m, score: breakdown.total, tier: scoreTier(breakdown.total), components: breakdown.components, health, evidenceItems };
      })
    );
    setResultLabel(`${qaSite === "all" ? "브랜드 전체" : siteName(qaSite as SiteKey)} · ${qaCategory === "all" ? "제품 전체" : productCategoryKo(qaCategory)} · ${qaMetric === "all" ? "지표 전체" : METRICS[qaMetric as MetricTab].label}`);
    setResults(rows);
  };

  return (
    <div className={`floatingChat ${open ? "open" : ""}`}>
      {!open && <button className="chatToggle" onClick={() => setOpen(true)}>💡 Quick View</button>}
      {open && (
        <div className="chatPanel">
          <div className="chatPanelHead">
            <b>💡 Quick View</b>
            <button onClick={() => setOpen(false)} title="닫기">×</button>
          </div>
          <div className="qaPickRow">
            <select value={qaSite} onChange={(e) => handleQaSiteChange(e.target.value)}>
              <option value="all">브랜드 전체</option>
              {allQaSites.map((s) => <option key={s} value={s}>{siteName(s)}</option>)}
            </select>
            <select value={qaCategory} onChange={(e) => setQaCategory(e.target.value)}>
              <option value="all">제품 전체</option>
              {availableCategories.map((c) => <option key={c} value={c}>{productCategoryKo(c)}</option>)}
            </select>
            <select value={qaMetric} onChange={(e) => setQaMetric(e.target.value)}>
              <option value="all">지표 전체</option>
              <option value="data">DATA / Schema</option>
              <option value="copy">COPY / CTA</option>
              <option value="visual">VISUAL / ALT COPY</option>
            </select>
          </div>
          <button className="qaPickGo qaPickGoFull" onClick={askStructured}>점수·신호등·근거 보기</button>

          {results && (
            <div className="qaResultWrap">
              <p className="qaResultLabel">{resultLabel}</p>
              {results.length === 0 ? (
                <p className="muted">{resultLabel}</p>
              ) : results.map((r, i) => {
                const avg = computeMetricAverages(dcv)[r.metric];
                const compDelta = r.score != null && avg.compTotal != null ? r.score - avg.compTotal : null;
                const prodDelta = r.score != null && avg.prodTotal != null ? r.score - avg.prodTotal : null;
                const isLastOfSite = i === results.length - 1 || results[i + 1].site !== r.site;
                return (
                <div key={`${r.site}-${r.metric}-${i}`} className="qaResultRow">
                  <p className="qaResultHead">
                    <span className={`badge ${siteClass(r.site)}`}>{siteName(r.site)}</span>
                    <span className="qaResultMetric">{METRICS[r.metric].label}</span>
                    <span className={`scoreDot ${r.tier}`} />
                    <span className="scoreVal">{r.score == null ? "근거 없음" : `${r.score}점 · ${scoreTierLabel(r.tier)}`}</span>
                  </p>
                  <p className="qaResultCompare">
                    경쟁사 평균 {avg.compTotal == null ? "-" : `${avg.compTotal}점`}{deltaMark(compDelta)}
                    {" · "}제품 평균 {avg.prodTotal == null ? "-" : `${avg.prodTotal}점`}{deltaMark(prodDelta)}
                  </p>
                  <div className="qaResultComponents">
                    {r.components.map((c) => {
                      const ca = avg.compComp[c.label] ?? null;
                      const d = c.value != null && ca != null ? c.value - ca : null;
                      return (
                        <div key={c.label} className="qaCompRow">
                          <span>{c.label}</span>
                          <span>{c.value == null ? "-" : `${c.value}%`}{ca != null ? ` · 경쟁사 평균 ${ca}%` : ""}{deltaMark(d)}</span>
                        </div>
                      );
                    })}
                    <p className="qaCompReason">→ 위 항목을 종합해 {METRICS[r.metric].label} {r.score == null ? "-" : `${r.score}점`}으로 판단</p>
                  </div>
                  <p className="qaResultSummary">{r.health.summary}</p>
                  {r.evidenceItems.length > 0 && (
                    <ul className="qaResultEvidence">
                      {r.evidenceItems.map((item, j) => (
                        <li key={j}>
                          {item.text}
                          {item.url && (
                            <a href={item.url} target="_blank" rel="noreferrer" className="qaResultUrl">{shortUrl(item.url)}</a>
                          )}
                        </li>
                      ))}
                    </ul>
                  )}
                  {isLastOfSite && onNavigateSite && (
                    <button className="qaResultCta" onClick={() => onNavigateSite(r.site)}>
                      {siteName(r.site)} 상세 보기 →
                    </button>
                  )}
                </div>
              );})}
            </div>
          )}
          <p className="muted" style={{ marginTop: 8 }}>현재 수집된 facts/changes 안에서만 점수와 근거를 rule-based로 보여줍니다.</p>
        </div>
      )}
    </div>
  );
}
