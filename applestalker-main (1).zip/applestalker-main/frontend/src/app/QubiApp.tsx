"use client";
/**
 * QubiApp.tsx — 큐비 🐝 (QA Bee) 독립 앱
 * 탭: [스키마 QA] [스펙 QA] · 제품×페이지타입 선택 · 입력 3종(붙여넣기/파일/링크)
 * 스펙 관리(메인 표) · 스키마 룰 추가(타입 드롭다운) · Quick View + 권역 신호등
 */
import { useEffect, useMemo, useRef, useState, Fragment } from "react";
import { Finding, PageResult, SiteRow, CatalogItem, Product, SEV, HONEY, PAGE_TYPES, pageTypesFor, family, tierOf, inputStyle, sel } from "./qubiShared";
import { CriteriaPanel, ScorePanel, QuickView } from "./QubiSections";
import { HtmlQaSummary, SiteOverview } from "./QubiDataQa";
import { SpecSiteOverview, SpecQaDetails, DictionaryPanel, DictionaryReviewSection, SpecV2RuleTable, SpecV2Criteria, SpecV2Score } from "./QubiSpecQa";
import { QubiSidebar } from "./QubiSidebar";
import { QubiRunPanel } from "./QubiRunPanel";

export default function QubiApp({ apiBase = "", onHome }: { apiBase?: string; onHome?: () => void }) {
  const [tab, setTab] = useState<"schema" | "copy">("schema");
  // [2026-07 과제3] 마지막으로 실행한 QA 축(all/data/spec) — 탭별 독립 실행 표시용
  const [qaMode, setQaMode] = useState<"all" | "data" | "spec">("all");
  const [product, setProduct] = useState("galaxy-z-fold8");
  const [v2Products, setV2Products] = useState<string[]>([]); // Rule DB(V2)가 있는 제품 — 기준/점수 패널을 V2판으로 게이트
  const isV2 = v2Products.includes(product);
  const [pageType, setPageType] = useState("PDP");
  const [selectedProducts, setSelectedProducts] = useState<Set<string>>(new Set(["galaxy-z-fold8"])); // 크롤 대상 제품(제품 버튼과 동기화)
  const [selectedPageTypes, setSelectedPageTypes] = useState<Set<string>>(new Set(["PDP"])); // 배치 크롤용 타입 멀티선택
  const [results, setResults] = useState<PageResult[]>([]);
  const [qaExpandedSite, setQaExpandedSite] = useState<string | null>(null); // HTML QA 일괄검수 드릴다운(사이트별 펼침)
  const [rules, setRules] = useState<any>(null);
  const [showRules, setShowRules] = useState(false); // 검수 기준은 기본 숨김 — "ⓘ 검수 기준" 클릭 시 뿅 등장
  const rulesRef = useRef<HTMLDivElement | null>(null);
  const [rulesFlash, setRulesFlash] = useState(false);
  const openCriteria = () => {
    setShowRuleAdd(false);
    setShowScore(false);   // 점수 패널은 닫고
    setShowRules(true);
    // 패널로 스크롤 + 잠깐 하이라이트(뿅!)
    setTimeout(() => {
      rulesRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      setRulesFlash(true);
      setTimeout(() => setRulesFlash(false), 1200);
    }, 60);
  };
  const openScore = () => {
    setShowRuleAdd(false);
    setShowRules(false);   // 검수 기준은 닫고
    setShowScore(true);
    setTimeout(() => {
      scoreRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 60);
  };
  const hideAll = () => { setShowRules(false); setShowScore(false); };
  const [showRuleAdd, setShowRuleAdd] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");
  const [online, setOnline] = useState<boolean | null>(null);

  const [regionsMap, setRegionsMap] = useState<Record<string, SiteRow[]>>({});
  // [2026-07 신규] 나라코드(sitecode)당 한 줄로 뭉개지 않은 전체 행 — URL 관리
  // 목록/삭제는 이걸 써야 한다(한 나라에 제품×페이지타입별로 여러 행이 있으므로).
  const [entries, setEntries] = useState<SiteRow[]>([]);
  const [pageCount, setPageCount] = useState(0);
  // [2026-07 신규] Z8/Watch9/WatchUltra2 국가별 출시여부 — 미출시 배지용(Task C).
  // {sitecode: {phone, watch_ultra2, watch9, category}}
  const [launchStatus, setLaunchStatus] = useState<Record<string, { phone?: string; watch_ultra2?: string; watch9?: string; category?: string }>>({});
  const [selectedRegions, setSelectedRegions] = useState<Set<string>>(new Set()); // 권역 다중선택(비었으면 전체)
  const [showScore, setShowScore] = useState(false); // 점수 계산 로직 패널
  const scoreRef = useRef<HTMLDivElement>(null);
  const regionRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const scrollToRegion = (region: string) => {
    const el = regionRefs.current[region];
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const [selectedSites, setSelectedSites] = useState<Set<string>>(new Set()); // 사이트 개별 다중선택(우선)
  const [progress, setProgress] = useState({ active: false, done: 0, total: 0, label: "" });
  const [estimate, setEstimate] = useState<{ totalPages: number; estimatedSeconds: number; sampleRuns: number } | null>(null);
  const runStartRef = useRef<number>(0); // runByRegion 시작 시각(ms) — 진행 중 남은시간 추정용

  const [sitesOpen, setSitesOpen] = useState(false);
  const xlsxFileRef = useRef<HTMLInputElement>(null);

  // 스펙 관리
  const [catalog, setCatalog] = useState<CatalogItem[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [specProduct, setSpecProduct] = useState("galaxy-z-fold8");
  const [specs, setSpecs] = useState<any[]>([]);
  const [newProd, setNewProd] = useState("");
  const [specForm, setSpecForm] = useState({ category: "", value: "", unit: "" });
  const [schemaTypes, setSchemaTypes] = useState<string[]>([]);
  const [ruleForm, setRuleForm] = useState({ block_type: "", property: "", value: "", value_kind: "exists", nested: "", kind: "spec", token: "" });

  // Quick View
  const [quickOpen, setQuickOpen] = useState(false);
  const [expandedRow, setExpandedRow] = useState<number | null>(null);
  const [qCountry, setQCountry] = useState("전체");
  const [qDetail, setQDetail] = useState<string | null>(null);

  // 검수 이력
  const [history, setHistory] = useState<any[]>([]);
  const [runId, setRunId] = useState<string | null>(null); // 현재 화면에 표시 중인 결과의 run_id — Excel/메일이 화면과 같은 데이터를 받도록 서버에 전달
  const [overview, setOverview] = useState<any>(null); // 전사이트 현황(각 권역 최신 검수 AEO 평균)

  const api = (p: string) => `${apiBase}${p}`;
  const flash = (m: string) => { setOk(m); setTimeout(() => setOk(""), 2500); };
  const J = (b: any) => ({ method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b) });

  useEffect(() => {
    fetch(api("/api/health")).then((r) => setOnline(r.ok)).catch(() => setOnline(false));
    loadSites(); loadCatalog(); loadProducts(); loadSpecs("galaxy-z-fold8"); loadHistory(); loadOverview();
    fetch(api("/api/qb/spec-rules/products")).then((r) => r.json())
      .then((d) => {
        const codes = (d.products || []).map((p: any) => p.product);
        if (codes.length) setV2Products((prev) => Array.from(new Set([...prev, ...codes])));
      }).catch(() => {});
  }, []);
  useEffect(() => { loadRules(); setSpecProduct(product); }, [product, pageType]);
  useEffect(() => { if (!pageTypesFor(product).includes(pageType)) setPageType("PDP"); }, [product]);
  useEffect(() => { loadSpecs(specProduct); }, [specProduct]);

  async function loadSites() { try { const d = await (await fetch(api("/api/qb/sites"))).json(); setRegionsMap(d.regions || {}); setEntries(d.entries || []); setPageCount(d.page_count || 0); setLaunchStatus(d.launch_status || {}); } catch { /* */ } }
  // [2026-07 신규] 현재 선택된 제품이 launch_status의 어느 키(phone/watch9/watch_ultra2)에 해당하는지.
  // 해당 없는 제품(S26, Buds4 등)은 null → 배지 표시 안 함.
  const launchKeyForProduct = (p: string): "phone" | "watch9" | "watch_ultra2" | null => {
    if (p.startsWith("galaxy-z-fold8") || p.startsWith("galaxy-z-flip8")) return "phone";
    if (p === "galaxy-watch9") return "watch9";
    if (p === "galaxy-watch-ultra2") return "watch_ultra2";
    return null;
  };
  const isUnlaunched = (sitecode: string): boolean => {
    const key = launchKeyForProduct(product);
    if (!key) return false;
    const v = launchStatus[sitecode]?.[key];
    return v === "미출시";
  };
  async function loadCatalog() { try { setCatalog((await (await fetch(api("/api/qb/spec-catalog"))).json()).catalog || []); } catch { /* */ } }
  async function loadProducts() {
    try {
      const ps = (await (await fetch(api("/api/qb/products"))).json()).products || [];
      setProducts(ps);
      // [견고성] /spec-rules/products 호출이 실패해도(배포 불일치 등) 제품 목록의 v2 플래그로 게이트가 열리게 병합
      const flagged = ps.filter((p: any) => p.v2).map((p: any) => p.code);
      if (flagged.length) setV2Products((prev) => Array.from(new Set([...prev, ...flagged])));
    } catch { /* */ }
  }
  async function loadSpecs(p: string) { try { setSpecs((await (await fetch(api(`/api/qb/specs?product=${encodeURIComponent(p)}`))).json()).specs || []); } catch { /* */ } }
  async function loadRules() {
    try { const d = await (await fetch(api(`/api/qb/rules?product=${family(product)}&page_type=${pageType}&market_product=${encodeURIComponent(product)}`))).json(); setRules(d); if (d.schema_types) setSchemaTypes(d.schema_types); } catch (e: any) { setErr(String(e)); }
  }
  async function loadHistory() { try { setHistory((await (await fetch(api("/api/qb/history"))).json()).history || []); } catch { /* */ } }
  async function loadOverview() { try { setOverview(await (await fetch(api("/api/qb/overview"))).json()); } catch { /* */ } }
  const openHistory = async (id: string) => {
    try { const d = await (await fetch(api(`/api/qb/history/${id}`))).json(); setResults(d.results || []); setRunId(id); flash(`이력 ${id} 불러옴`); loadOverview(); }
    catch { setErr("이력 불러오기 실패"); }
  };
  const removeHistory = async (id: string) => { await fetch(api("/api/qb/history/remove"), J({ run_id: id })); loadHistory(); loadOverview(); }; // [2026-07] 이력 삭제 → 전사이트 현황도 즉시 재계산

  const allSites = useMemo(() => Object.entries(regionsMap).flatMap(([rg, arr]) => arr.map((s) => ({ ...s, region: rg }))), [regionsMap]);
  const regionNames = useMemo(() => Object.keys(regionsMap), [regionsMap]);

  // ── 검수 ──
  // Apple Stalker의 trigger-crawl/all + crawl-progress 패턴과 동일:
  // /run 은 즉시 반환(started)되고, 실제 크롤은 서버 백그라운드에서 동시성 제한으로
  // '나눠서' 진행된다. 프론트는 SSE로 진행률만 구독하다가 done 이벤트에서 결과를 받아온다.
  // → 91개를 한 요청에 다 물지 않으므로 'Failed to fetch'(게이트웨이 타임아웃)가 사라진다.
  const targetCodes = useMemo(() => {
    if (selectedSites.size > 0) return Array.from(selectedSites);
    if (selectedRegions.size > 0) return allSites.filter((s) => selectedRegions.has(s.region || "")).map((s) => s.sitecode);
    return allSites.map((s) => s.sitecode); // 아무것도 안 고르면 전체
  }, [selectedSites, selectedRegions, allSites]);

  // [2026-07 신규] 선택(사이트/제품/페이지타입) 바뀔 때마다 예상 소요시간 조회(디바운스).
  // 실제 이력 기반 페이지당 평균초 × 대상 페이지수 — /run 실행 전 미리 보여줌.
  useEffect(() => {
    if (allSites.length === 0) return; // 사이트 목록 로딩 전 불필요한 호출 방지
    const t = setTimeout(() => {
      fetch(api("/api/qb/run-estimate"), J({
        sitecodes: targetCodes,
        products: Array.from(selectedProducts),
        page_types: Array.from(selectedPageTypes),
      })).then((r) => r.json())
        .then((d) => setEstimate({ totalPages: d.total_pages || 0, estimatedSeconds: d.estimated_seconds || 0, sampleRuns: d.sample_runs || 0 }))
        .catch(() => setEstimate(null));
    }, 400);
    return () => clearTimeout(t);
  }, [targetCodes, selectedProducts, selectedPageTypes, allSites.length]);

  const fmtEta = (secs: number) => {
    if (secs <= 0) return "0초";
    if (secs < 60) return `${Math.round(secs)}초`;
    const m = Math.floor(secs / 60), s = Math.round(secs % 60);
    return s > 0 ? `${m}분 ${s}초` : `${m}분`;
  };

  // 진행 중일 때 남은시간 = (지금까지 걸린시간 / 완료수) × 남은 페이지수 — 실시간 실측 기반이라
  // 사전 예상치보다 더 정확해진다(첫 몇 페이지 완료 이후부터).
  const liveEtaSeconds = useMemo(() => {
    if (!progress.active || progress.done === 0 || !runStartRef.current) return null;
    const elapsed = (Date.now() - runStartRef.current) / 1000;
    const perPage = elapsed / progress.done;
    return Math.max(0, Math.round(perPage * (progress.total - progress.done)));
  }, [progress.done, progress.total, progress.active]);

  // [2026-07 과제3] Data QA / Spec QA 독립 실행. mode ∈ {"all","data","spec"}.
  //   "data" = Data QA 탭(스키마·검색노출)만, "spec" = Spec QA 탭(스펙 정확성)만 크롤·검수.
  //   각각 상대 축의 무거운 작업을 건너뛰어 크롤 시간을 줄인다(기본 all=하위호환).
  // [2026-07 신규] overrideCodes: "실패한 사이트만 재시도" 버튼용. setSelectedSites() 직후 바로
  // runByRegion을 호출하면 targetCodes(useMemo)가 아직 리렌더 전 값이라 예전 선택 상태로 나갈
  // 위험이 있어, 재시도 시엔 계산된 sitecode 목록을 state 갱신과 무관하게 직접 넘긴다.
  const runByRegion = async (mode: "all" | "data" | "spec" = "all", overrideCodes?: string[]) => {
    if (busy) return;
    setBusy(true); setErr(""); setResults([]); setRunId(null);
    runStartRef.current = Date.now();
    setQaMode(mode);
    const codes = overrideCodes && overrideCodes.length ? overrideCodes : targetCodes;
    if (codes.length === 0) { setErr("검수할 사이트를 하나 이상 선택하세요."); setBusy(false); return; }
    const modeLabel = mode === "data" ? "Data QA" : mode === "spec" ? "Spec QA" : "";
    const baseLabel = overrideCodes ? `재시도 ${codes.length}개` : (selectedSites.size ? `사이트 ${codes.length}개` : (selectedRegions.size ? Array.from(selectedRegions).join(", ") : "전체"));
    const label = modeLabel ? `${baseLabel} · ${modeLabel}` : baseLabel;
    setProgress({ active: true, done: 0, total: codes.length, label });
    try {
      const r = await fetch(api("/api/qb/run"), J({
        product: family(product), market_product: product, sitecodes: codes,
        products: Array.from(selectedProducts),
        page_types: Array.from(selectedPageTypes),
        mode,
      }));
      if (r.status === 501) throw new Error("크롤러 미연결 — 붙여넣기/파일/링크 검수를 이용하세요.");
      if (r.status === 409) {
        // 이전 검수가 서버에 갇힌 상태일 수 있음 — 강제 해제 후 1회 재시도
        await fetch(api("/api/qb/run-reset"), { method: "POST" }).catch(() => {});
        const retry = await fetch(api("/api/qb/run"), J({
          product: family(product), market_product: product, sitecodes: codes,
          products: Array.from(selectedProducts), page_types: Array.from(selectedPageTypes), mode,
        }));
        if (!retry.ok) throw new Error(retry.status === 409 ? "이미 검수가 진행 중이에요. 잠시 후 다시 시도하세요." : `실행 실패 (${retry.status})`);
      } else if (!r.ok) {
        throw new Error(`실행 실패 (${r.status})`);
      }
      await new Promise<void>((resolve, reject) => {
        const es = new EventSource(api("/api/qb/run-progress"));
        const timeout = setTimeout(() => { es.close(); reject(new Error("진행이 오래 걸려요 — 검수 이력에서 완료 여부를 확인해보세요.")); }, 20 * 60 * 1000);
        es.onmessage = (ev) => {
          try {
            const d = JSON.parse(ev.data);
            if (d.type === "start") setProgress((p) => ({ ...p, total: d.total || p.total, done: 0 }));
            else if (d.type === "page_done") setProgress((p) => ({ ...p, done: d.done ?? p.done + 1 }));
            else if (d.type === "done") {
              clearTimeout(timeout); es.close();
              fetch(api(`/api/qb/history/${encodeURIComponent(d.run_id)}`))
                .then((rr) => rr.ok ? rr.json() : null)
                .then((dd) => { if (dd?.results) { setResults(dd.results); setRunId(d.run_id); } resolve(); })
                .catch(() => resolve());
            } else if (d.type === "status" && d.crawling === false) { clearTimeout(timeout); es.close(); resolve(); }
            else if (d.type === "error") { clearTimeout(timeout); es.close(); reject(new Error(d.message || "크롤 중 오류가 발생했어요.")); }
          } catch { /* heartbeat 무시 */ }
        };
        es.onerror = () => { clearTimeout(timeout); es.close(); reject(new Error("진행 상황 연결이 끊겼어요 — 완료 후 검수 이력에서 확인하세요.")); };
      });
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); setProgress((p) => ({ ...p, active: false })); loadHistory(); loadOverview(); }
  };

  const downloadBlob = async (url: string, body: any, filename: string) => {
    try {
      const r = body === null
        ? await fetch(api(url))
        : await fetch(api(url), J(body));
      if (!r.ok) throw new Error(`서버 오류 (${r.status})`);
      const blob = await r.blob();
      const href = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = href; a.download = filename; document.body.appendChild(a); a.click();
      a.remove(); setTimeout(() => URL.revokeObjectURL(href), 1500);
    } catch (e: any) {
      setErr(`${filename} 다운로드 실패 — ${e.message || e}`);
    }
  };
  const reportQs = () => (runId ? `?run_id=${encodeURIComponent(runId)}` : ""); // 화면에 보이는 이력과 동일 데이터 보장
  const emailQs = () => { // 메일은 현재 탭 내용만 — schema/copy 중 지금 보는 것만 복사
    const base = runId ? `?run_id=${encodeURIComponent(runId)}` : "?";
    return `${base}${base.endsWith("?") ? "" : "&"}tab=${tab}`;
  };
  const downloadXlsx = async () => {
    if (!results.length) { setErr("먼저 검수를 실행한 뒤 Excel을 받을 수 있어요."); return; }
    await downloadBlob(`/api/qb/report.xlsx${reportQs()}`, null, `qubi_qa_report${runId ? `_${runId}` : ""}.xlsx`); // [2026-07] 파일명에 run_id — 어느 검수의 리포트인지 파일만 봐도 구분
  };
  const copyEmail = async () => {
    if (!results.length) { setErr("먼저 검수를 실행한 뒤 메일 본문을 복사할 수 있어요."); return; }
    try {
      // Apple Stalker와 동일: 본문 없는 GET(CORS preflight 회피). run_id가 있으면 그 이력을, 없으면 서버가 든 마지막 결과를 받음
      const r = await fetch(api(`/api/qb/email-draft${emailQs()}`), { cache: "no-store" });
      if (!r.ok) throw new Error(`서버 오류 (${r.status})`);
      const body = await r.text();
      if (navigator.clipboard && "write" in navigator.clipboard && typeof ClipboardItem !== "undefined") {
        await navigator.clipboard.write([new ClipboardItem({ "text/html": new Blob([body], { type: "text/html" }), "text/plain": new Blob([body], { type: "text/plain" }) })]);
        flash("메일 본문 복사됨 — 붙여넣기 🐝");
      } else if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(body); flash("메일 본문 복사됨 🐝"); }
      else { const w = window.open("", "_blank"); if (w) { w.document.write(body); w.document.close(); } flash("새 탭에서 복사하세요"); }
    } catch (e: any) { setErr(`메일 복사 실패 — ${e.message || e}`); }
  };

  // ── URL 관리 ──
  const removeUrl = async (sc: string, url: string) => { await fetch(api("/api/qb/sites/remove"), J({ sitecode: sc, url })); loadSites(); };
  const downloadTemplate = () => downloadBlob("/api/qb/sites/template.xlsx", null, "qubi_url_template.xlsx");
  const uploadTemplate = async (file: File) => {
    const b64: string = await new Promise((res, rej) => { const rd = new FileReader(); rd.onload = () => res(String(rd.result)); rd.onerror = rej; rd.readAsDataURL(file); });
    const d = await (await fetch(api("/api/qb/sites/upload"), J({ b64 }))).json(); loadSites(); flash(`${d.added || 0}개 URL 추가`);
  };

  // ── 스펙/제품/룰 ──
  const pickCatalog = (cat: string) => { const c = catalog.find((x) => x.category === cat); setSpecForm({ category: cat, value: c?.ex_value || "", unit: c?.ex_unit || "" }); };
  const addSpec = async () => { if (!specForm.category || !specForm.value) return; await fetch(api("/api/qb/specs/add"), J({ product: specProduct, ...specForm })); setSpecForm({ category: "", value: "", unit: "" }); loadSpecs(specProduct); flash("스펙 추가"); };
  const removeSpec = async (i: number) => { await fetch(api("/api/qb/specs/remove"), J({ index: i, product: specProduct })); loadSpecs(specProduct); };
  const addProduct = async () => { if (!newProd.trim()) return; await fetch(api("/api/qb/products/add"), J({ product: newProd.trim() })); const p = newProd.trim(); setNewProd(""); await loadProducts(); setSpecProduct(p); flash("제품 추가"); };
  const addRule = async () => {
    if (tab === "schema") {
      if (!ruleForm.block_type || !ruleForm.property) return;
      await fetch(api("/api/qb/rules/schema/add"), J({
        product: family(product), page_type: pageType, block_type: ruleForm.block_type, property: ruleForm.property,
        value: ruleForm.value, value_kind: ruleForm.value_kind, nested: ruleForm.nested,
      }));
    } else {
      if (!ruleForm.token) return;
      await fetch(api("/api/qb/rules/copy/add"), J({ product, kind: ruleForm.kind, token: ruleForm.token }));
    }
    setRuleForm({ ...ruleForm, property: "", value: "", token: "" }); loadRules(); flash("룰 추가됨");
  };

  // 현재 탭 오류 행 — Quick View·flat 테이블 공용.
  // [V2 정합] 스펙 탭에서 결과가 spec_v2(Rule DB 판정)를 가지면 화면(SpecV2Panel)과 동일한
  // 소스에서 행을 만든다: Critical=룰 fail, Warning=미등록 표현(candidates).
  // N/A(못 찾음·페이지타입 미적용)는 오류가 아니므로 Quick View에 싣지 않는다.
  // spec_v2가 없는 제품(S26 등)만 기존 copy findings 폴백 — 메인 화면과 같은 분기 원칙.
  const rows = useMemo(() => {
    const out: { r: PageResult; f: Finding; item: string }[] = [];
    for (const r of results) {
      if (tab === "schema") {
        // [정합] 화면(HtmlQaDetail)은 '번역 확인 필요'처럼 실제 오류(값불일치·속성누락·@id/hasPart·name이슈)가
        // 없는 안내성 finding은 판정근거에서 제외한다. Quick View도 같은 기준을 써야 100점인데 오류로 뜨는 불일치가 사라진다.
        for (const f of r.schema?.findings || []) {
          if (f.status !== "fail" && f.status !== "warn") continue;
          const hasReal = (f.val_mismatch || []).length || (f.missing_props || []).length ||
                          (f.name_issue || []).length || f.id_mismatch || (f.haspart_missing || []).length;
          const onlyTranslate = (f.translate_confirm || []).length && !hasReal;
          if (onlyTranslate) continue;
          out.push({ r, f, item: f.block || f.token || f.category || "" });
        }
      } else if (r.spec_v2) {
        // [2026-07 Quick View 정합] 종합 배너(summary.critical/warning)와 완전히 같은 소스:
        // 오류 = 룰 fail, 확인 = 엔진 warn(재확인 필요). 미등록 표현(candidates)은 점수·배너와
        // 무관한 보조 기능이므로 Quick View에서 제외 — Dictionary Review 섹션에서만 다룬다.
        for (const it of r.spec_v2.items || []) {
          if (it.status !== "fail" && it.status !== "warn") continue;
          out.push({
            r, item: it.attribute,
            f: { status: it.status, category: it.category, region: it.section,
                 as_is: it.found ? `현재 '${it.found}'` : (it.message || "값 불일치"),
                 to_be: it.status === "fail"
                   ? `기준 ${it.expected}${it.unit ? ` ${it.unit}` : ""}${it.fix_guide ? ` — ${it.fix_guide}` : ""}`
                   : `기준 ${it.expected}${it.unit ? ` ${it.unit}` : ""} — ${it.message || "재확인 필요"}`,
                 expected: `${it.expected}${it.unit ? ` ${it.unit}` : ""}`,
                 found: it.found ? [String(it.found)] : [] },
          });
        }
      } else {
        // 스펙 탭인데 spec_v2가 없는 결과(seed 미등록 제품 등) → 구 카피엔진 폴백을 쓰지 않는다.
        // (구 엔진은 페이지의 임의 숫자를 스펙으로 오인해 허위 오류를 만들었음 — 표시 안 함)
      }
    }
    const rank: Record<string, number> = { fail: 0, warn: 1, na: 2 };
    return out.sort((a, b) => (rank[a.f.status] ?? 3) - (rank[b.f.status] ?? 3));
  }, [results, tab]);
  const failCount = rows.filter((x) => x.f.status === "fail").length;

  // 권역 신호등
  // 권역 신호등 — [V2 정합] 현재 탭 기준으로만 집계(기존엔 schema+copy 합산이라 탭 화면과 불일치).
  // 스펙 탭: spec_v2 있으면 summary(critical/warning) 그대로 — SpecV2Panel 종합 배너와 같은 숫자.
  // 한 결과에서 스키마/스펙 각각의 (fail,warn) 집계 헬퍼 — 두 곳(현재탭 신호등·양탭 신호등)에서 공용
  const schemaCount = (r: any) => {
    let fail = 0, warn = 0;
    for (const f of r.schema?.findings || []) {
      if (f.status !== "fail" && f.status !== "warn") continue;
      const hasReal = (f.val_mismatch || []).length || (f.missing_props || []).length ||
                      (f.name_issue || []).length || f.id_mismatch || (f.haspart_missing || []).length;
      if ((f.translate_confirm || []).length && !hasReal) continue;  // 안내성 제외
      if (f.status === "fail") fail++; else warn++;
    }
    return { fail, warn };
  };
  const specCount = (r: any) => {
    if (r.spec_v2) return { fail: r.spec_v2.summary?.critical || 0, warn: r.spec_v2.summary?.warning || 0 };
    return { fail: 0, warn: 0 };  // seed 미등록 → 구 카피엔진 쓰지 않음(허위 카운트 방지)
  };
  // 현재 탭 기준 권역 신호등 (Quick View 오류목록·요약과 동일 기준)
  const regionTier = useMemo(() => {
    const m: Record<string, { fail: number; warn: number }> = {};
    for (const r of results) {
      const rg = r.region || "기타"; m[rg] = m[rg] || { fail: 0, warn: 0 };
      const c = tab === "schema" ? schemaCount(r) : specCount(r);
      m[rg].fail += c.fail; m[rg].warn += c.warn;
    }
    return m;
  }, [results, tab]);
  // 두 탭 동시 표시용 — 한 사이트가 "스키마 초록·스펙 빨강"인 걸 한눈에
  const regionTierBoth = useMemo(() => {
    const m: Record<string, { schema: { fail: number; warn: number }; spec: { fail: number; warn: number } }> = {};
    for (const r of results) {
      const rg = r.region || "기타";
      m[rg] = m[rg] || { schema: { fail: 0, warn: 0 }, spec: { fail: 0, warn: 0 } };
      const sc = schemaCount(r), sp = specCount(r);
      m[rg].schema.fail += sc.fail; m[rg].schema.warn += sc.warn;
      m[rg].spec.fail += sp.fail; m[rg].spec.warn += sp.warn;
    }
    return m;
  }, [results]);

  const countries = useMemo(() => Array.from(new Set(results.map((r) => r.country).filter(Boolean))) as string[], [results]);
  const quickRows = useMemo(() => rows.filter((x) => qCountry === "전체" || x.r.country === qCountry), [rows, qCountry]);

  // QubiSections.tsx 로 분리한 렌더 블록에 상태·핸들러를 한 번에 주입
  const ctx = {
    tab, product, pageType, rules, showRules, showRuleAdd, rulesRef, rulesFlash, qaExpandedSite, setQaExpandedSite, overview,
    showScore, scoreRef, regionRefs, scrollToRegion,
    specProduct, setSpecProduct, products, newProd, setNewProd, addProduct, v2Products, isV2,
    specs, removeSpec, catalog, specForm, pickCatalog, setSpecForm, addSpec,
    ruleForm, setRuleForm, schemaTypes, addRule,
    quickOpen, setQuickOpen, results, regionTier, regionTierBoth, countries, qCountry, setQCountry,
    quickRows, qDetail, setQDetail, api, flash,
  };

  return (
    <div className="appShell">
      {/* ── 사이드바 ── */}
      <QubiSidebar onHome={onHome} online={online} downloadTemplate={downloadTemplate} uploadTemplate={uploadTemplate} xlsxFileRef={xlsxFileRef} sitesOpen={sitesOpen} setSitesOpen={setSitesOpen} entries={entries} removeUrl={removeUrl} history={history} openHistory={openHistory} removeHistory={removeHistory} />

      {/* ── 메인 ── */}
      <div className="mainArea">
        <header className="topbar">
          <div className="topbarRow1">
            <div className="tabGroup">
              <button className={`tabBtn ${tab === "schema" ? "on" : ""}`} onClick={() => setTab("schema")}>DATA QA</button>
              <button className={`tabBtn ${tab === "copy" ? "on" : ""}`} onClick={() => setTab("copy")}>스펙 QA</button>
            </div>
            <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
              <button className="toolBtn" onClick={() => (showRules ? setShowRules(false) : openCriteria())}>
                {showRules ? "ⓘ 검수 기준 숨기기" : "ⓘ 검수 기준 보기"}
              </button>
              <button className="toolBtn" onClick={() => (showScore ? setShowScore(false) : openScore())}>
                {showScore ? "ⓘ 점수 계산 숨기기" : "ⓘ 점수 계산 보기"}
              </button>
              <button className="toolBtn" onClick={copyEmail}>✉ 메일 복사</button>
              <button className="toolBtn" onClick={downloadXlsx}>📊 Excel</button>
            </div>
          </div>
        </header>

        <div className="contentScroll" style={{ padding: "20px 28px 80px" }}>
          <h2 style={{ fontSize: 18, margin: "0 0 4px" }}>
            {tab === "schema" ? "DATA QA" : "스펙 QA"} <span style={{ fontSize: 12, fontWeight: 400, color: "var(--sec)" }}>
              {tab === "schema" ? "스키마 · H태그 · Meta title/description — GEO 관점 종합 검수" : "스펙 값·고유명사 정확성 (번역 대응)"}</span>
          </h2>

          <SiteOverview ctx={ctx} />
          {/* [2026-07] Spec QA도 DATA QA와 동일 문법 — 맨 위엔 종합 점수 + 권역별 보기만,
              PDP/Compare별 상세 오류·확인 현황은 아래쪽(HtmlQaSummary 자리)으로 이동 */}
          <SpecSiteOverview ctx={ctx} />

          {/* 제품 — 클릭 시: 화면·검수기준표는 그 제품 하나를 보여주고(product), 크롤 대상엔 토글로 누적/해제(selectedProducts 다중). */}
          <div style={{ display: "flex", gap: 6, alignItems: "center", margin: "10px 0 4px", flexWrap: "wrap" }}>
            <span style={{ fontSize: 12.5, color: "var(--sec)" }}>제품:</span>
            {products.filter((p) => !p.spec_only).map((p) => {
              const shown = product === p.code;          // 파란 테두리 = 지금 화면에 보이는 제품
              const inCrawl = selectedProducts.has(p.code); // ✓ = 크롤 대상에 포함
              // [2026-07 신규] 이 제품이 launch_status상 미출시인 국가가 하나라도 있으면 배지 표시.
              const lKey = launchKeyForProduct(p.code);
              const hasUnlaunched = lKey ? Object.values(launchStatus).some((v) => v?.[lKey] === "미출시") : false;
              return <button key={p.code} onClick={() => {
                setProduct(p.code);  // 화면·검수기준표를 이 제품으로
                setSelectedProducts((prev) => { const n = new Set(prev); n.has(p.code) ? (n.size > 1 && n.delete(p.code)) : n.add(p.code); return n; });
              }} style={{ ...sel(p.code, inCrawl), ...(shown ? { boxShadow: "0 0 0 2px #0A66E0 inset" } : {}) }} title={hasUnlaunched ? "일부 국가 미출시" : undefined}>
                {inCrawl ? "✓ " : ""}{p.label}{hasUnlaunched ? <span style={{ marginLeft: 4, fontSize: 10, color: "#B54708" }}>미출시 있음</span> : null}
              </button>;
            })}
            <span style={{ fontSize: 12.5, color: "var(--sec)", marginLeft: 10 }}>페이지타입:</span>
            {PAGE_TYPES.map((p) => {
              const on = selectedPageTypes.has(p);
              return <button key={p} onClick={() => {
                setPageType(p);
                setSelectedPageTypes((prev) => { const n = new Set(prev); n.has(p) ? (n.size > 1 && n.delete(p)) : n.add(p); return n; });
              }} style={sel(p, on)}>{on ? "✓ " : ""}{p}</button>;
            })}
          </div>

          {ok && <div style={{ background: "#ECFDF3", color: "#067647", padding: "8px 12px", borderRadius: 8, fontSize: 13, margin: "8px 0" }}>{ok}</div>}
          {err && <div style={{ background: "#FEF3F2", color: "#B42318", padding: 10, borderRadius: 8, fontSize: 13, margin: "8px 0", fontWeight: 600 }}>{err}</div>}

          {/* ① 리전별 검수 크롤 (91사이트) — 먼저 노출 */}
          <QubiRunPanel allSites={allSites} busy={busy} estimate={estimate} fmtEta={fmtEta} liveEtaSeconds={liveEtaSeconds} pageCount={pageCount} progress={progress} regionNames={regionNames} regionsMap={regionsMap} runByRegion={runByRegion} selectedRegions={selectedRegions} selectedSites={selectedSites} setSelectedRegions={setSelectedRegions} setSelectedSites={setSelectedSites} tab={tab} targetCodes={targetCodes} isUnlaunched={isUnlaunched} results={results} />

          {/* 스펙 탭은 V2(Rule DB) 전용. V2 제품이면 Rule DB 뷰어+기준+점수, 비V2(seed 미등록)면 준비중 안내.
              스키마 탭에서는 구 CriteriaPanel/ScorePanel이 동작. */}
          {tab === "copy" && isV2 && <SpecV2RuleTable product={product} api={api} flash={flash} />}
          {tab === "copy" && isV2 && <SpecV2Criteria show={showRules} panelRef={rulesRef} />}
          {tab === "copy" && isV2 && <SpecV2Score show={showScore} panelRef={scoreRef} />}
          {tab === "copy" && !isV2 && (
            <div className="card" style={{ marginTop: 18, padding: 16, background: "#FFFAEB", border: "1px solid #FEDF89" }}>
              <b style={{ fontSize: 13.5, color: "#93540A" }}>이 제품은 아직 스펙 검수 기준(Rule DB)이 등록되지 않았어요</b>
              <p style={{ fontSize: 12, color: "#93540A", margin: "6px 0 0", lineHeight: 1.6 }}>
                <b>{product}</b>의 Rule DB가 준비되면 스펙 검수가 활성화됩니다. 스펙 탭의 <b>Rule DB 엑셀 업로드</b>로 등록하거나, 담당자에게 시드 등록을 요청하세요. (스키마 검수는 Data QA 탭에서 정상 이용 가능)
              </p>
            </div>
          )}
          {tab === "schema" && <CriteriaPanel ctx={ctx} />}
          {tab === "schema" && <ScorePanel ctx={ctx} />}
          <HtmlQaSummary ctx={ctx} />
          <SpecQaDetails ctx={ctx} />

          {/* ═══ Spec QA [V2] — 상단 "스펙 현황" + 위 SpecQaDetails에서 사이트별 상세. 여기서는 Dictionary Review만 ═══ */}
          {tab === "copy" && results.some((r: any) => r.spec_v2) && (
            <DictionaryReviewSection results={results} product={product} api={api} flash={flash} />
          )}
          {/* Dictionary는 검수 결과와 무관하게 상시(좌측 하단 플로팅) — 스펙 탭 & V2 제품일 때 */}
          {tab === "copy" && isV2 && <DictionaryPanel product={product} api={api} />}

          {/* 결과 — 오류 빨강 강조. AEO(schema) 탭은 위 HtmlQaSummary 그룹으로 대체하므로 스펙(copy) 탭에서만 flat 테이블 노출
              [V2] spec_v2가 있으면 위 새 화면으로 교체되고, 룰셋 없는 제품만 기존 테이블로 폴백 */}
          {tab === "copy" && !results.some((r: any) => r.spec_v2) && rows.length > 0 && (
            <>
              <div style={{ margin: "18px 0 8px", fontSize: 13, fontWeight: 700, color: failCount ? "#B42318" : "var(--label)" }}>
                {failCount ? `🔴 오류 ${failCount}건` : "🟡 검토"}
                {(() => { const w = rows.filter((x) => x.f.status === "warn").length;
                  return <span style={{ color: "var(--sec)", fontWeight: 400 }}> · 확인 {w}건</span>; })()}
              </div>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                <thead><tr style={{ color: "var(--sec)", fontSize: 11, textAlign: "left" }}>
                  <th style={{ padding: "6px 8px" }}>사이트</th><th style={{ padding: "6px 8px" }}>항목</th><th style={{ padding: "6px 8px" }}>심각도</th><th style={{ padding: "6px 8px" }}>as-is → to-be</th></tr></thead>
                <tbody>
                  {rows.map((x, i) => (
                    <Fragment key={i}>
                      <tr onClick={() => setExpandedRow(expandedRow === i ? null : i)}
                        style={{ background: x.f.status === "fail" ? "#FEF3F2" : undefined, opacity: x.f.status === "na" ? 0.6 : 1, cursor: "pointer" }}>
                        <td style={{ padding: 8, borderTop: "1px solid var(--line)", whiteSpace: "nowrap" }}>{x.r.sitecode}</td>
                        <td style={{ padding: 8, borderTop: "1px solid var(--line)" }}>{x.item}</td>
                        <td style={{ padding: 8, borderTop: "1px solid var(--line)", whiteSpace: "nowrap" }}><span style={{ display: "inline-block", background: SEV[x.f.status].c, color: "#fff", fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 5, whiteSpace: "nowrap", lineHeight: 1.5 }}>{SEV[x.f.status].ko}</span></td>
                        <td style={{ padding: 8, borderTop: "1px solid var(--line)" }}><div style={{ color: "var(--sec)" }}>{x.f.as_is}</div>{x.f.to_be ? <div style={{ fontWeight: 600, color: x.f.status === "fail" ? "#B42318" : "var(--label)" }}>→ {x.f.to_be}</div> : null}<div style={{ fontSize: 11, color: "#0A66E0", marginTop: 3 }}>{expandedRow === i ? "▲ 근거 접기" : "▼ 상세 근거"}</div></td>
                      </tr>
                      {expandedRow === i && (
                        <tr>
                          <td colSpan={4} style={{ padding: "12px 14px", background: "#F9FAFB", borderTop: "1px solid var(--line)" }}>
                            {/* 문제 → 수정 방법 */}
                            <div style={{ marginBottom: 10 }}>
                              <div style={{ fontSize: 11, fontWeight: 700, color: "var(--sec)" }}>무엇이 잘못됐나</div>
                              <div style={{ fontSize: 12.5, color: "var(--label)", marginTop: 2 }}>{x.f.as_is || "—"}</div>
                              {x.f.to_be && <>
                                <div style={{ fontSize: 11, fontWeight: 700, color: "var(--sec)", marginTop: 6 }}>어떻게 고치나</div>
                                <div style={{ fontSize: 12.5, fontWeight: 600, color: x.f.status === "fail" ? "#B42318" : "var(--label)", marginTop: 2 }}>→ {x.f.to_be}</div>
                              </>}
                            </div>
                            {/* 발생 위치·근거 */}
                            <div style={{ display: "grid", gridTemplateColumns: "90px 1fr", gap: "4px 10px", fontSize: 12 }}>
                              <span style={{ color: "var(--sec)" }}>사이트코드</span><b>{x.r.sitecode}</b>
                              {x.r.country && <><span style={{ color: "var(--sec)" }}>국가</span><span>{x.r.country}</span></>}
                              {x.r.region && <><span style={{ color: "var(--sec)" }}>권역</span><span>{x.r.region}</span></>}
                              {x.r.page_type && <><span style={{ color: "var(--sec)" }}>페이지타입</span><span>{x.r.page_type}</span></>}
                              {x.f.region && <><span style={{ color: "var(--sec)" }}>발견 위치</span><span>{x.f.region === "disclaimer" ? "각주(Disclaimer)" : "본문"}</span></>}
                              {x.f.expected && <><span style={{ color: "var(--sec)" }}>기준값</span><span>{x.f.expected}</span></>}
                              {x.f.found && x.f.found.length > 0 && <><span style={{ color: "var(--sec)" }}>페이지 값</span><span style={{ color: "#B42318" }}>{x.f.found.join(", ")}</span></>}
                              {x.r.url && <><span style={{ color: "var(--sec)" }}>URL</span><a href={x.r.url} target="_blank" rel="noreferrer" style={{ fontFamily: "monospace", fontSize: 11, color: "#0A66E0", wordBreak: "break-all" }}>{x.r.url}</a></>}
                            </div>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  ))}
                </tbody>
              </table>
            </>
          )}
          {tab === "copy" && !results.some((r: any) => r.spec_v2) && results.length > 0 && rows.length === 0 && <p style={{ color: "#1F9E5C", marginTop: 16 }}>이 탭(스펙)에서 발견된 오류가 없어요 🐝</p>}
        </div>
      </div>

      {/* Quick View (QubiSections.tsx로 분리) */}
      <QuickView ctx={ctx} />
    </div>
  );
}
