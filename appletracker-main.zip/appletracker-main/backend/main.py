import asyncio
import json as pyjson
from fastapi import FastAPI, BackgroundTasks, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from apscheduler.schedulers.background import BackgroundScheduler
from sqlalchemy import func
from database import init_db, SessionLocal
from crawler import run_crawler, subscribe_progress, unsubscribe_progress, TIERS, set_stop_flag_getter
from analyzer import generate_pov
from differ import compare_runs, build_summary_text, build_snapshot_summary
from models import POVReport, HistoricalRecord, ChangeRecord

app = FastAPI(title="Competitive Tracker Intelligence API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

_crawling_in_progress = False
_auto_crawl_enabled   = True   # 자동 크롤링 on/off 상태 (재시작 시 초기화)
_crawl_stop_requested = False  # 중단 요청 플래그


def _prev_run_id(current: str):
    db = SessionLocal()
    try:
        rows = (db.query(HistoricalRecord.crawl_run_id, HistoricalRecord.timestamp)
                .distinct(HistoricalRecord.crawl_run_id)
                .order_by(HistoricalRecord.timestamp.desc()).all())
        ids = [r[0] for r in rows]
        if current in ids:
            idx = ids.index(current)
            if idx + 1 < len(ids): return ids[idx + 1]
        return None
    finally:
        db.close()


def run_full_pipeline(tiers: list[str] | None = None):
    """
    tiers: 크롤링할 Tier 목록. None이면 전체.
    """
    global _crawling_in_progress, _crawl_stop_requested
    _crawling_in_progress  = True
    _crawl_stop_requested  = False
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        run_id = loop.run_until_complete(run_crawler(tiers=tiers))
        prev = _prev_run_id(run_id)
        if prev:
            changes = compare_runs(run_id, prev)
            summary = build_summary_text(changes) if changes else build_snapshot_summary(run_id)
        else:
            summary = build_snapshot_summary(run_id)
        # 변경 유무와 관계없이 항상 LLM 분석 실행
        generate_pov(run_id, summary)
        return run_id
    finally:
        _crawling_in_progress = False
        _crawl_stop_requested = False


def scheduled_job():
    if _auto_crawl_enabled:
        run_full_pipeline()
    else:
        print("자동 크롤링이 비활성화 상태입니다. 스킵.")


@app.on_event("startup")
def startup_event():
    init_db()
    set_stop_flag_getter(lambda: _crawl_stop_requested)
    scheduler = BackgroundScheduler()
    scheduler.add_job(scheduled_job, "cron", hour="9,14")
    scheduler.start()


@app.get("/")
def health_check():
    return {"status": "ok", "message": "Tracker API is running"}


# ── 설정 조회 ────────────────────────────────────────────────────────────────
@app.get("/api/settings")
def get_settings():
    return {
        "auto_crawl_enabled": _auto_crawl_enabled,
        "crawling": _crawling_in_progress,
        "available_tiers": list(TIERS.keys()),
        "tier_counts": {tier: len(urls) for tier, urls in TIERS.items()},
    }


# ── 자동 크롤링 on/off ────────────────────────────────────────────────────────
@app.post("/api/auto-crawl")
def set_auto_crawl(body: dict):
    global _auto_crawl_enabled
    enabled = body.get("enabled")
    if enabled is None:
        return JSONResponse(status_code=400, content={"message": "enabled 필드가 필요합니다."})
    _auto_crawl_enabled = bool(enabled)
    return {"auto_crawl_enabled": _auto_crawl_enabled}


# ── 크롤링 중단 요청 ──────────────────────────────────────────────────────────
@app.post("/api/crawl-stop")
def stop_crawl():
    global _crawl_stop_requested
    if not _crawling_in_progress:
        return JSONResponse(status_code=409, content={"message": "크롤링 중이 아닙니다."})
    _crawl_stop_requested = True
    return {"message": "중단 요청이 접수됐습니다. 현재 페이지 완료 후 멈춥니다."}


# ── 크롤링 상태 ───────────────────────────────────────────────────────────────
@app.get("/api/crawl-status")
def crawl_status():
    return {
        "crawling": _crawling_in_progress,
        "stop_requested": _crawl_stop_requested,
        "auto_crawl_enabled": _auto_crawl_enabled,
    }


# ── SSE: 진행 상황 실시간 스트리밍 ──────────────────────────────────────────
@app.get("/api/crawl-progress")
async def crawl_progress():
    q = subscribe_progress()

    async def event_generator():
        try:
            yield f"data: {pyjson.dumps({'type': 'status', 'crawling': _crawling_in_progress})}\n\n"
            while True:
                try:
                    event = await asyncio.wait_for(q.get(), timeout=30.0)
                    yield f"data: {pyjson.dumps(event)}\n\n"
                    if event.get("type") in ("done", "stopped"):
                        break
                except asyncio.TimeoutError:
                    yield f"data: {pyjson.dumps({'type': 'heartbeat'})}\n\n"
        finally:
            unsubscribe_progress(q)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ── 수동 크롤링 트리거 (Tier 선택 가능) ─────────────────────────────────────
@app.post("/trigger-crawl/{site_name}")
def trigger_crawl(site_name: str, background_tasks: BackgroundTasks, body: dict = None):
    """
    body: { "tiers": ["Tier 0", "Tier 1", ...] }  — 생략 시 전체 Tier
    """
    if _crawling_in_progress:
        return JSONResponse(status_code=409, content={"message": "이미 크롤링이 진행 중입니다."})
    tiers = None
    if body and "tiers" in body:
        tiers = [t for t in body["tiers"] if t in TIERS]
        if not tiers:
            return JSONResponse(status_code=400, content={"message": "유효한 Tier가 없습니다."})
    background_tasks.add_task(run_full_pipeline, tiers)
    return {"message": "Crawl triggered.", "tiers": tiers or list(TIERS.keys())}


@app.get("/api/runs")
def get_runs():
    db = SessionLocal()
    try:
        rows = (db.query(
            HistoricalRecord.crawl_run_id,
            func.min(HistoricalRecord.timestamp).label("ts"),
            func.count(HistoricalRecord.id).label("pages"),
        ).group_by(HistoricalRecord.crawl_run_id)
         .order_by(func.min(HistoricalRecord.timestamp).desc())
         .limit(20).all())
        result = []
        for row in rows:
            changed = db.query(ChangeRecord).filter(ChangeRecord.crawl_run_id == row.crawl_run_id).count()
            result.append({
                "run_id": row.crawl_run_id,
                "timestamp": row.ts.isoformat() if row.ts else None,
                "pages_crawled": row.pages,
                "changed_urls": changed,
            })
        return {"runs": result}
    finally:
        db.close()


@app.get("/api/latest-report")
def get_latest_report(run_id: str = Query(default=None)):
    db = SessionLocal()
    try:
        q = db.query(POVReport).order_by(POVReport.id.desc())
        if run_id:
            q = q.filter(POVReport.crawl_run_id == run_id)
        pov = q.first()
        if not pov:
            return {"error": "아직 리포트가 없습니다. 수동 크롤링을 먼저 실행해주세요."}

        changes = (db.query(ChangeRecord)
                   .filter(ChangeRecord.crawl_run_id == pov.crawl_run_id)
                   .order_by(ChangeRecord.severity_score.desc()).all())
        sample = db.query(HistoricalRecord).filter(
            HistoricalRecord.crawl_run_id == pov.crawl_run_id
        ).first()
        top = changes[0] if changes else None

        def sj(v):
            try: return pyjson.loads(v) if v else []
            except: return []
        def sd(v):
            try: return pyjson.loads(v) if v else {}
            except: return {}

        data_changes = []
        for c in changes:
            if c.added_lines + c.removed_lines > 0:
                data_changes.append({
                    "url": c.url, "site": c.site_name, "tier": c.tier,
                    "added": c.added_lines, "removed": c.removed_lines,
                    "title_changed": bool(c.title_changed),
                    "severity": c.severity_label,
                    "severity_score": c.severity_score or 0,
                    "change_types": sj(c.change_types_json),
                })
        data_changes = data_changes[:10]
        content_changes = [
            {"url": c.url, "site": c.site_name, "tier": c.tier}
            for c in changes if c.title_changed
        ][:6]

        cat_insights = sd(pov.category_insights_json) if hasattr(pov, "category_insights_json") else {}

        return {
            "run_id": pov.crawl_run_id,
            "url": top.url if top else (sample.url if sample else "N/A"),
            "site_name": top.site_name if top else (sample.site_name if sample else "N/A"),
            "tier": top.tier if top else (sample.tier if sample else "N/A"),
            "timestamp": pov.timestamp.isoformat() if pov.timestamp else None,
            "analysis": {
                "change_summary":      pov.change_summary or "",
                "consumer_perception": pov.consumer_perception or "",
                "samsung_comparison":  pov.samsung_comparison or "",
                "insights":            sj(pov.insights_json),
                "action_items":        sj(pov.action_items_json),
                "priority_label":      pov.priority_label or "Medium",
                "functional_area":     pov.functional_area or "",
                "category_insights":   cat_insights,
            },
            "data_changes":       data_changes,
            "content_changes":    content_changes,
            "total_changed_urls": len(changes),
        }
    finally:
        db.close()


@app.get("/api/run-detail/{run_id}")
def get_run_detail(run_id: str):
    db = SessionLocal()
    try:
        records = (db.query(HistoricalRecord)
                   .filter(HistoricalRecord.crawl_run_id == run_id)
                   .order_by(HistoricalRecord.tier, HistoricalRecord.url).all())
        changes  = db.query(ChangeRecord).filter(ChangeRecord.crawl_run_id == run_id).all()
        change_map = {c.url: c for c in changes}

        def sj(v):
            try: return pyjson.loads(v) if v else []
            except: return []
        def sd(v):
            try: return pyjson.loads(v) if v else {}
            except: return {}

        pages = []
        for r in records:
            c = change_map.get(r.url)
            pages.append({
                "url": r.url, "site": r.site_name, "tier": r.tier,
                "title": r.title or "",
                "body_content": r.body_content or "",
                "timestamp": r.timestamp.isoformat() if r.timestamp else None,
                "changed": c is not None,
                "severity": c.severity_label if c else None,
                "severity_score": c.severity_score if c else 0,
                "change_types": sj(c.change_types_json) if c else [],
                "added_lines": c.added_lines if c else 0,
                "removed_lines": c.removed_lines if c else 0,
                "diff_summary": c.diff_summary if c else "",
                "diff_detail": sd(c.diff_detail_json) if c else {},
            })

        grouped: dict = {}
        for p in pages:
            t = p["tier"]
            if t not in grouped: grouped[t] = []
            grouped[t].append(p)

        return {"run_id": run_id, "total": len(records), "changed_count": len(changes), "tiers": grouped}
    finally:
        db.close()


@app.delete("/api/run/{run_id}")
def delete_run(run_id: str):
    db = SessionLocal()
    try:
        db.query(ChangeRecord).filter(ChangeRecord.crawl_run_id == run_id).delete()
        db.query(POVReport).filter(POVReport.crawl_run_id == run_id).delete()
        db.query(HistoricalRecord).filter(HistoricalRecord.crawl_run_id == run_id).delete()
        db.commit()
        return {"message": "Run deleted."}
    finally:
        db.close()

