import re
import json
import difflib
from database import SessionLocal
from models import HistoricalRecord, ChangeRecord


def _strip_tags(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html)
    return re.sub(r"\s+", " ", text).strip()


def _get_headings(html: str) -> list:
    headings = []
    for m in re.finditer(r'<(h[1-3])[^>]*>(.*?)</h[1-3]>', html, re.IGNORECASE | re.DOTALL):
        tag  = m.group(1).lower()
        text = re.sub(r'<[^>]+>', '', m.group(2)).strip()
        if text and len(text) > 2:
            headings.append({"tag": tag, "text": text[:120]})
    return headings[:10]


def _extract_meta(html: str) -> dict:
    """title / og:title / meta description / og:description 추출"""
    meta = {}
    t = re.search(r'<title[^>]*>(.*?)</title>', html, re.IGNORECASE | re.DOTALL)
    if t:
        meta["title"] = re.sub(r'<[^>]+>', '', t.group(1)).strip()[:200]
    for prop in ["og:title", "og:description", "og:image"]:
        m = re.search(rf'property=["\']{{0,1}}{re.escape(prop)}["\']{{0,1}}[^>]+content=["\']([^"\']+)["\']', html, re.IGNORECASE)
        if not m:
            m = re.search(rf'content=["\']([^"\']+)["\'][^>]+property=["\']{{0,1}}{re.escape(prop)}', html, re.IGNORECASE)
        if m:
            meta[prop] = m.group(1).strip()[:300]
    desc = re.search(r'name=["\']description["\'][^>]+content=["\']([^"\']+)["\']', html, re.IGNORECASE)
    if not desc:
        desc = re.search(r'content=["\']([^"\']+)["\'][^>]+name=["\']description["\']', html, re.IGNORECASE)
    if desc:
        meta["meta_description"] = desc.group(1).strip()[:300]
    return meta


def _extract_schema_types(html: str) -> list:
    types = []
    for m in re.finditer(r'"@type"\s*:\s*"([^"]+)"', html):
        t = m.group(1)
        if t not in types:
            types.append(t)
    return types[:15]


def _extract_cta_texts(html: str) -> list:
    ctas = []
    for m in re.finditer(r'<(?:a|button)[^>]*>(.*?)</(?:a|button)>', html, re.IGNORECASE | re.DOTALL):
        text = re.sub(r'<[^>]+>', '', m.group(1)).strip()
        if 3 < len(text) < 80:
            ctas.append(text)
    return list(dict.fromkeys(ctas))[:20]


def _extract_prices(html: str) -> list:
    prices = re.findall(r'(?:S\$|SGD|USD|\$|₩|¥|£|€)\s*[\d,]+(?:\.\d{1,2})?', html)
    return list(dict.fromkeys(prices))[:10]


def _extract_img_alts(html: str) -> list:
    alts = []
    for m in re.finditer(r'<img[^>]+>', html, re.IGNORECASE):
        a = re.search(r'alt=["\']([^"\']{4,})["\']', m.group(0), re.IGNORECASE)
        if a:
            alts.append(a.group(1).strip()[:100])
    return list(dict.fromkeys(alts))[:15]


def _extract_sections(html: str) -> dict:
    sections = {}
    for m in re.finditer(r'<h[1-3][^>]*>(.*?)</h[1-3]>', html, re.IGNORECASE | re.DOTALL):
        heading = re.sub(r'<[^>]+>', '', m.group(1)).strip()[:80]
        if not heading or len(heading) < 3:
            continue
        following = html[m.end(): m.end() + 600]
        text = re.sub(r'<[^>]+>', ' ', following)
        text = re.sub(r'\s+', ' ', text).strip()[:250]
        sections[heading] = text
    return sections


def _build_detail(old_html: str, new_html: str, old_title: str, new_title: str) -> dict:
    detail = {"title": None, "images": [], "sections": []}
    if old_title != new_title:
        detail["title"] = {"old": old_title, "new": new_title}
    old_alts = set(_extract_img_alts(old_html))
    new_alts = set(_extract_img_alts(new_html))
    for alt in (new_alts - old_alts):
        detail["images"].append({"status": "추가", "alt": alt})
    for alt in (old_alts - new_alts):
        detail["images"].append({"status": "제거", "alt": alt})
    old_sec = _extract_sections(old_html)
    new_sec = _extract_sections(new_html)
    for heading, new_text in list(new_sec.items())[:8]:
        old_text = old_sec.get(heading)
        if old_text is None:
            detail["sections"].append({"heading": heading, "status": "신규 섹션", "new": new_text[:200]})
        elif old_text.strip() != new_text.strip() and len(new_text) > 10:
            detail["sections"].append({"heading": heading, "status": "텍스트 변경",
                                        "old": old_text[:180], "new": new_text[:180]})
    return detail


# ─── 7개 카테고리 변경 유형 감지 ────────────────────────────────────────────

def _detect_change_types(raw_old, raw_new, diff_snippets, title_changed, added, removed):
    types = set()
    added_text  = " ".join(l[1:] for l in diff_snippets.split("\n") if l.startswith("+"))
    added_lower = added_text.lower()

    schema_kw = ["application/ld+json", '"@type"', "og:title", "og:description",
                 "og:image", "meta name=", "meta property="]
    for kw in schema_kw:
        if raw_old.lower().count(kw) != raw_new.lower().count(kw):
            types.add("SEO·AI 인덱싱"); break
    if title_changed:
        types.add("SEO·AI 인덱싱")

    if re.search(r"(SGD|S\$|\$\s*\d|\d+\s*%|save|off|from\s+\$|promo|discount|trade.?in|instalment|installment|월\s*\d|할부)",
                 added_lower, re.IGNORECASE):
        types.add("가격·프로모션")

    old_h = {h["text"] for h in _get_headings(raw_old)}
    new_h = {h["text"] for h in _get_headings(raw_new)}
    if old_h != new_h:
        types.add("헤드라인·슬로건")

    for tag in ["<img", "<video", "<picture"]:
        if raw_old.lower().count(tag) != raw_new.lower().count(tag):
            types.add("비주얼·미디어"); break
    if set(_extract_img_alts(raw_old)) != set(_extract_img_alts(raw_new)):
        types.add("비주얼·미디어")

    nav_kw = ["<nav", "<header", "nav-item", "breadcrumb", "navigation", "menu-item"]
    if sum(raw_old.lower().count(k) for k in nav_kw) != sum(raw_new.lower().count(k) for k in nav_kw):
        types.add("내비게이션·구조")

    cta_kw = r"(buy now|shop now|add to cart|get started|order now|지금 구매|구매하기|shop iphone|shop galaxy)"
    if re.search(cta_kw, added_lower, re.IGNORECASE):
        types.add("CTA·구매 흐름")
    old_buy = len(re.findall(r'href=["\'][^"\']*(?:buy|shop|cart)[^"\']*["\']', raw_old, re.IGNORECASE))
    new_buy = len(re.findall(r'href=["\'][^"\']*(?:buy|shop|cart)[^"\']*["\']', raw_new, re.IGNORECASE))
    if old_buy != new_buy:
        types.add("CTA·구매 흐름")

    if not types and (added > 3 or removed > 3):
        types.add("본문·기능 설명")
    elif (added > 15 or removed > 15) and len(types) > 0:
        types.add("본문·기능 설명")

    return sorted(types) if types else ["본문·기능 설명"]


TYPE_WEIGHTS = {
    "SEO·AI 인덱싱":  35, "가격·프로모션":   35, "헤드라인·슬로건": 30,
    "비주얼·미디어":   25, "내비게이션·구조": 25, "CTA·구매 흐름":  20, "본문·기능 설명":  10,
}
TIER_BONUS = {"Tier 0": 20, "Tier 2": 15, "Tier 1": 10, "Tier 3": 5, "Tier 4": 0}


def _calc_severity(change_types, tier, added, removed, title_changed):
    score = sum(TYPE_WEIGHTS.get(t, 5) for t in change_types)
    score += TIER_BONUS.get(tier, 0)
    total = added + removed
    if total >= 100:  score += 15
    elif total >= 50: score += 10
    elif total >= 15: score += 5
    if len(change_types) >= 3: score += 15
    elif len(change_types) == 2: score += 8
    if title_changed: score += 15
    score = min(100, score)
    if score >= 70:   label = "Critical"
    elif score >= 45: label = "High"
    elif score >= 20: label = "Medium"
    else:             label = "Low"
    return score, label


# ─── 메인 비교 함수 ─────────────────────────────────────────────────────────

def compare_runs(current_run_id: str, previous_run_id: str) -> list:
    db = SessionLocal()
    try:
        current_records = db.query(HistoricalRecord).filter(
            HistoricalRecord.crawl_run_id == current_run_id
        ).all()
        saved = []
        for rec in current_records:
            prev = db.query(HistoricalRecord).filter(
                HistoricalRecord.crawl_run_id == previous_run_id,
                HistoricalRecord.url == rec.url,
            ).first()
            if not prev:
                continue
            curr_lines = _strip_tags(rec.body_content or "").splitlines()
            prev_lines = _strip_tags(prev.body_content or "").splitlines()
            diff = list(difflib.unified_diff(prev_lines, curr_lines, lineterm=""))
            added   = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
            removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))
            title_changed = rec.title != prev.title
            if added + removed == 0 and not title_changed:
                continue
            snippets = [l[1:].strip() for l in diff
                        if l.startswith("+") and not l.startswith("+++") and len(l.strip()) > 4][:8]
            diff_excerpt = "\n".join(snippets)
            change_types = _detect_change_types(
                prev.body_content or "", rec.body_content or "",
                diff_excerpt, title_changed, added, removed,
            )
            severity_score, severity_label = _calc_severity(change_types, rec.tier, added, removed, title_changed)
            detail = _build_detail(prev.body_content or "", rec.body_content or "", prev.title or "", rec.title or "")
            change = ChangeRecord(
                crawl_run_id=current_run_id,
                url=rec.url, site_name=rec.site_name, tier=rec.tier,
                title_changed=int(title_changed),
                added_lines=added, removed_lines=removed,
                severity_score=severity_score, severity_label=severity_label,
                diff_summary=diff_excerpt,
                change_types_json=json.dumps(change_types, ensure_ascii=False),
                diff_detail_json=json.dumps(detail, ensure_ascii=False),
            )
            db.add(change)
            saved.append(change)
        db.commit()
        for c in saved: db.refresh(c)
        return saved
    finally:
        db.close()


def build_summary_text(changes: list) -> str:
    if not changes: return ""
    lines = ["경쟁사 웹사이트에서 다음 변경점이 감지되었습니다:"]
    for c in changes[:15]:
        types = json.loads(c.change_types_json) if c.change_types_json else []
        lines.append(f"\n[{c.tier}] {c.site_name} — {c.url}")
        lines.append(f"  • 심각도: {c.severity_label} ({c.severity_score}/100점)")
        if types: lines.append(f"  • 변경 유형: {', '.join(types)}")
        if c.title_changed: lines.append("  • 페이지 제목 변경")
        lines.append(f"  • 규모: +{c.added_lines}줄 / -{c.removed_lines}줄")
        if c.diff_summary:
            lines.append(f"  • 변경 내용 샘플: {c.diff_summary[:300]}")
    return "\n".join(lines)


def build_snapshot_summary(run_id: str) -> str:
    """
    Apple vs Samsung 구조화 비교 데이터를 생성.
    사이트별·Tier별로 분리하고 SEO/헤드라인/가격/CTA/이미지/스키마 등
    실제 추출 데이터를 풍부하게 담아 LLM이 심층 분석할 수 있게 한다.
    """
    db = SessionLocal()
    try:
        records = db.query(HistoricalRecord).filter(
            HistoricalRecord.crawl_run_id == run_id
        ).order_by(HistoricalRecord.tier).all()

        apple_pages   = [r for r in records if r.site_name == "Apple"]
        samsung_pages = [r for r in records if r.site_name == "Samsung"]

        def page_block(r: HistoricalRecord) -> str:
            html  = r.body_content or ""
            meta  = _extract_meta(html)
            heads = _get_headings(html)
            ctas  = _extract_cta_texts(html)
            prices = _extract_prices(html)
            alts   = _extract_img_alts(html)
            schemas = _extract_schema_types(html)
            plain  = _strip_tags(html)[:400]

            lines = [f"  [{r.tier}] {r.url}"]
            if r.title:
                lines.append(f"    페이지 제목: {r.title}")
            if meta.get("meta_description"):
                lines.append(f"    Meta Description: {meta['meta_description']}")
            if meta.get("og:title"):
                lines.append(f"    OG Title: {meta['og:title']}")
            if heads:
                h_texts = " / ".join(f"{h['tag'].upper()}: {h['text']}" for h in heads[:5])
                lines.append(f"    헤드라인: {h_texts}")
            if ctas:
                lines.append(f"    CTA 버튼: {' | '.join(ctas[:6])}")
            if prices:
                lines.append(f"    가격 정보: {' | '.join(prices)}")
            if alts:
                lines.append(f"    이미지 ALT: {' | '.join(alts[:5])}")
            if schemas:
                lines.append(f"    JSON-LD 스키마: {', '.join(schemas)}")
            if plain:
                lines.append(f"    본문 요약: {plain[:300]}")
            return "\n".join(lines)

        lines = [
            "COMPETITIVE SNAPSHOT — Apple vs Samsung 현행 분석",
            f"크롤링 페이지 수: Apple {len(apple_pages)}개, Samsung {len(samsung_pages)}개",
            "=" * 60,
        ]

        lines.append("\n■ APPLE 페이지 현황")
        for r in apple_pages:
            lines.append(page_block(r))

        lines.append("\n■ SAMSUNG 페이지 현황")
        for r in samsung_pages:
            lines.append(page_block(r))

        # 직접 비교 가능한 동일 Tier 페이지 쌍 강조
        tier_map: dict = {}
        for r in records:
            tier_map.setdefault(r.tier, {})[r.site_name] = r

        comparable = []
        for tier, sites in tier_map.items():
            if "Apple" in sites and "Samsung" in sites:
                a, s = sites["Apple"], sites["Samsung"]
                comparable.append(
                    f"  {tier}: Apple='{a.title or a.url}' vs Samsung='{s.title or s.url}'"
                )
        if comparable:
            lines.append("\n■ Tier별 직접 비교 가능 페이지")
            lines.extend(comparable)

        return "\n".join(lines)
    finally:
        db.close()

