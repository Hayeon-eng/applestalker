from sqlalchemy import Column, Integer, String, DateTime, Text
from database import Base
from datetime import datetime

class HistoricalRecord(Base):
    __tablename__ = "historical_records"
    id = Column(Integer, primary_key=True, index=True)
    site_name = Column(String, index=True)
    crawl_run_id = Column(String, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    url = Column(String)
    tier = Column(String)
    title = Column(String)
    body_content = Column(Text)
    html_snapshot_path = Column(String)
    screenshot_path = Column(String)

class ChangeRecord(Base):
    __tablename__ = "change_records"
    id = Column(Integer, primary_key=True, index=True)
    crawl_run_id = Column(String, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    url = Column(String)
    site_name = Column(String)
    tier = Column(String)
    title_changed = Column(Integer, default=0)
    added_lines = Column(Integer, default=0)
    removed_lines = Column(Integer, default=0)
    severity_score = Column(Integer, default=0)
    severity_label = Column(String)
    diff_summary = Column(Text)
    change_types_json = Column(Text)
    diff_detail_json = Column(Text)

class POVReport(Base):
    __tablename__ = "pov_reports"
    id = Column(Integer, primary_key=True, index=True)
    crawl_run_id = Column(String, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    change_summary = Column(Text)
    consumer_perception = Column(Text)
    samsung_comparison = Column(Text)
    insights_json = Column(Text)
    action_items_json = Column(Text)
    priority_label = Column(String)
    functional_area = Column(String)
    # snapshot(변경없음) 전용: 7개 카테고리별 현황 분석
    # 구조: { "카테고리명": { "status": "양호"|"주의"|"위험", "summary": "..." } }
    category_insights_json = Column(Text)
